globalThis.GLDN_WORKFLOW_GUIDE_CATALOG = Object.freeze({
  "version": "3.12.58",
  "updated": "2026-10-19",
  "safetyRule": "Final marketplace actions require explicit action-time approval. GLDN Ops must stop before eBay Continue, eBay Save, final listing Submit, purchase, or any equivalent irreversible action unless the operator approves that exact action.",
  "statusDefinitions": {
    "LIVE PASS": "Current signed-in evidence and exact readback prove the documented result.",
    "LIVE PASS WITH BOUNDARY": "The documented result passed live, but a named external or manual boundary remains.",
    "PENDING USER REVIEW": "Recorded evidence exists, but the user has not accepted the gate.",
    "PARTIAL": "Only the stated portion is proven. Do not assume the entire workflow works.",
    "IMPLEMENTED, UNPROVEN": "Code exists, but no valid current live proof exists.",
    "IMPLEMENTED, LIVE REVIEW PENDING": "The implementation and deterministic data checks pass, but the current signed-in marketplace review still needs to be reached."
  },
  "features": [
    {
      "id": "orders-left",
      "matrix": "E-17",
      "title": "Orders left to place",
      "status": "PARTIAL",
      "summary": "Count orders without a saved note, excluding canceled orders, and group them by weekday and order date directly on eBay Orders.",
      "prerequisites": [
        "Use the intended signed-in eBay Chrome profile.",
        "Update GLDN Ops, then refresh the native Orders tab.",
        "Choose the eBay status, search and period filters that should be included."
      ],
      "steps": [
        "Open eBay Orders. The Orders left to place section appears automatically under the heading.",
        "Wait for All pages read. GLDN reads the current filters across every available page in inactive helper tabs without moving the visible page.",
        "Read each weekday/date group. An order with any saved note is excluded, and canceled/cancelled orders are ignored. Several items in one order count once.",
        "Notes, dates or status hidden by the list are checked on the exact native order details. No note is created or edited.",
        "Saving a note or changing visible cancellation status refreshes the count. Use Recount for changes made elsewhere or a fresh all-page read.",
        "Stop leaves partial results. If eBay requires sign-in or verification, use Open reader, finish it manually, then Recount."
      ],
      "approvalStop": "This counter never purchases, cancels, ships or changes orders and never edits or saves an order note. Only order navigation, pagination and the native More actions menu are read.",
      "output": "A total and oldest-first weekday/date groups such as Thursday, 10/15 50 orders left. Partial reads show lower-bound counts and unresolved evidence, never a verified empty backlog.",
      "recovery": [
        "The count follows current eBay filters, not orders outside the selected period or status.",
        "Any saved note is the placed marker, even if it is not a GLDN profit note. An unsaved draft is not a saved note.",
        "Switching tabs or moving the source or reader between windows in the same browser profile does not stop the saved run. Stable order rows can be read while other page resources load.",
        "A remounted summary reconnects to its active read. Discarded readers reload once. If the browser freezes a reader, use Open reader to let it resume.",
        "Missing note/status/date evidence, changed totals, repeated/skipped pages, unknown navigation or a background restart keeps the result partial.",
        "The weekday comes from the actual order date and year. Prior-year groups include the year explicitly.",
        "State stays in this Chrome profile and is not shared with the dashboard. Recount after account or filter changes."
      ],
      "evidence": "Core and background tests cover unique order counts, dates, cancellation and note rules, saved reader ownership, sender rejection, normal/incognito separation, discarded/frozen recovery and partial completion. Synthetic real-extension desktop/mobile Chromium checks read three pages, resolve hidden notes in exact details, count nine mixed orders and 235 larger-set orders, update a saved-note change, retain the visible source page and make zero marketplace submissions. Recovery checks deliberately hold a resource loading, select another tab, move the source between windows and remount the summary without restarting the run. Current signed-in validation remains pending because the affected browser is not exposed through browser control."
    },
    {
      "id": "offer-review",
      "matrix": "E-16",
      "title": "Offer Review",
      "status": "PARTIAL",
      "summary": "See Amazon cost, estimated counteroffer profit and all-page buyer feedback directly on the native eBay offer page.",
      "prerequisites": [
        "Use the intended signed-in eBay Chrome profile.",
        "Open one native Offer Received page with a pending buyer offer.",
        "Confirm the Store plan, fee category, advertising rate, and estimated costs."
      ],
      "steps": [
        "Open a pending native Offer Received page; Offer insights appears inline. GLDN icon > Daily > Offer Review returns to this section; Separate view is optional.",
        "GLDN opens read-only background tabs in the same Chrome profile and window to resolve the listing SKU, read its exact Amazon item, and scan the buyer's Left for others feedback.",
        "If SKU matching is unavailable, enter the exact SKU, ASIN, or Amazon item link and choose Read Amazon. An operator-supplied match is not independently verified against the listing.",
        "Wait for Complete or All pages read. A header-total mismatch is shown explicitly, with percentages based on readable ratings. Partial means coverage is unfinished; Scan all feedback pages restarts from the beginning.",
        "Confirm the Store plan, fee category and advertising rate. Expand Fee and cost settings for Amazon tax/shipping, estimated buyer tax and other costs. Blank values are visibly excluded or assumed zero.",
        "Adjust Your counteroffer to compare estimated profit and margin. Copy amount and use eBay's unchanged native controls to submit manually."
      ],
      "approvalStop": "GLDN never accepts, declines, counters, blocks a buyer, purchases an item, or changes a listing. Final marketplace submission is manual.",
      "output": "An inline offer-specific review with timestamped Amazon evidence, expandable fee settings, estimated profit, and positive/neutral/negative counts and percentages plus comments. All-page coverage and header-total reconciliation are labeled separately.",
      "recovery": [
        "Sign-in or verification requires operator action in the relevant reader tab.",
        "Pause stops readers and preserves captured results; restart a partial feedback scan to verify full coverage.",
        "Different buyers, changed offers/titles/quantities, Amazon variation changes, skipped feedback pages and duplicate feedback IDs stop the relevant reader.",
        "Fee presets cover named common category groups; exceptions require a confirmed custom rate and per-order fee. Rates older than 45 days warn to check the official source.",
        "Saved reviews expire after fifteen minutes and restored Amazon prices are labeled with their original capture time."
      ],
      "evidence": "The reported public buyer's two native pages exposed 227 distinct ratings (222 positive, 4 neutral, 1 negative), despite a 235-entry header. Unit tests and synthetic desktop/mobile real-extension-API checks reproduce that mismatch, delayed loading, same-tab/window reader ownership, source navigation and zero marketplace submissions. Separate-view fixtures also cover 205 entries. Full new-helper signed-in Profile 2/video verification remains pending."
    },
    {
      "id": "price-increase",
      "matrix": "E-15",
      "title": "Price +$0.10",
      "status": "PARTIAL",
      "summary": "Prepare a ten-cent increase on one exact fixed-price eBay listing.",
      "prerequisites": [
        "Use the intended signed-in eBay Chrome profile.",
        "Open Order Details, the exact listing, or its native Revise editor.",
        "Finish or pause other marketplace workflows and clear Stop."
      ],
      "steps": [
        "Choose Price +$0.10 from Daily or the floating eBay panel.",
        "If an order contains multiple item links, choose the intended listing.",
        "GLDN follows the native Revise route and reads the current Item price.",
        "Check the displayed old and new price; only Item price is prepared.",
        "Review the native listing and click eBay Revise it yourself."
      ],
      "approvalStop": "GLDN never clicks Revise it, Save, Preview, Continue or final Submit. Final revision remains manual.",
      "output": "One prepared Item price exactly ten cents above the initial current price, with the old and new amounts visible.",
      "recovery": [
        "Repeated clicks resume the same prepared amount rather than increasing again.",
        "A reload does not automatically reapply an already-prepared edit; review the native current value.",
        "Close helper clears its pending session, not the edited native price.",
        "Auctions, active variations, ambiguous fields, changed prices and unverifiable redirects require manual review."
      ],
      "evidence": "The user's read-only AnyDesk demonstration showed 27.29 after 27.19. Current signed-in native Revise link, title, fixed-price control, disabled variations notice and Item price field were inspected without modification. Deterministic tests and synthetic browser checks support the implementation; a full live helper run and final revision are not claimed."
    },
    {
      "id": "unread-customer-messages",
      "matrix": "E-14",
      "title": "Unread Customer Messages",
      "status": "PARTIAL",
      "summary": "Collect unread customer conversations and open all pending messages while retaining local Ignore/Restore preferences.",
      "prerequisites": [
        "Use the intended signed-in eBay Chrome profile.",
        "Update GLDN Ops and refresh open marketplace tabs."
      ],
      "steps": [
        "Open the GLDN icon > Daily > Unread Customer Messages, or use the floating eBay panel button.",
        "Choose Scan Unread Messages. GLDN selects eBay Unread from members and reads pages or automatically loaded rows.",
        "Wait for Complete; an interrupted or unrecognized inbox remains Partial with Resume available.",
        "Choose Ignore on conversations you intentionally set aside, or select rows and Ignore Selected.",
        "Choose Open All Pending to open each remaining conversation in a separate eBay tab, or Open Selected for a subset.",
        "Use Ignored > Restore to return a saved conversation. Scan again to refresh native unread status."
      ],
      "approvalStop": "Opening conversations is user-initiated and can mark them read on eBay. No sending, deletion, archiving or replies are performed.",
      "output": "An account-specific saved unread snapshot with pending, ignored and opened counts, and exact customer conversation tabs.",
      "recovery": [
        "Ignore is stored only in this Chrome profile, separately for each eBay account.",
        "A changed preview returns an ignored thread to pending; an identical preview without a native latest-message ID cannot prove a new message.",
        "Complete requires a verified last page or settled scroll end, plus native unread-count reconciliation where available. Missing pagination stays Partial. Inbox batches include scrolling loads, not just numbered pages.",
        "Older Complete labels need a fresh full scan; saved messages and ignores remain unchanged.",
        "Finish sign-in or verification in the worker inbox, then Resume. A changed account or conversation stops opening."
      ],
      "evidence": "Historical Profile 2 inbox layout and native conversation IDs were inspected. v3.12.55 core/reader/controller tests and desktop/mobile real-DOM synthetic browser checks cover 75 messages across three native pages, 125-row virtual/lazy lists, later-page exact opening, Ignore preservation, unknown layouts and genuine empty folders. The current reported account's signed-in completion is not claimed."
    },
    {
      "id": "companion-setup",
      "matrix": "F-02",
      "title": "Optional Extension Setup",
      "status": "PARTIAL",
      "summary": "Open optional eComSniper download and Trackerbot installation/sign-in controls.",
      "prerequisites": [
        "Use the Chrome profile where the companion extension belongs."
      ],
      "steps": [
        "Click the GLDN Ops Chrome icon > Settings > Optional Extension Setup.",
        "Choose Download latest eComSniper, allow optional downloads, and sign in if needed.",
        "Wait for Chrome-confirmed download completion and use Show downloaded file. Extract the ZIP and use Chrome Load unpacked manually.",
        "For Trackerbot, choose Open Trackerbot in Chrome Web Store and approve Add to Chrome there.",
        "Use Open Trackerbot sign-in for its website, then finish any separate extension login in Trackerbot.",
        "Skip for now opens the feature tour without starting either provider."
      ],
      "approvalStop": "Chrome installation approval, verification, and separate extension login remain manual. No marketplace action is authorized.",
      "output": "A confirmed versioned eComSniper download or an opened official Trackerbot page; opening a page is not installation or sign-in proof.",
      "recovery": [
        "A blocked or interrupted download stays unconfirmed. Check the provider tab and Chrome before retrying.",
        "Passwords are not bundled or persisted by GLDN.",
        "The setup button remains available after skipping or updating."
      ],
      "evidence": "Provider pages were inspected during local development. Executable regression and synthetic UI tests cover behavior; a completed signed-in download and Trackerbot installation are not claimed."
    },
    {
      "id": "removed-listing-history",
      "matrix": "C-13",
      "title": "Removed Listing History",
      "status": "PARTIAL",
      "summary": "Learn from eBay's previous listing violations and share product-level prevention history across GLDN profiles.",
      "prerequisites": [
        "Use the intended signed-in eBay Chrome profile.",
        "Update GLDN Ops and connect every profile to the same dashboard."
      ],
      "steps": [
        "Open Removed Listing History in the popup.",
        "Choose Scan This eBay Account. GLDN reads Inactive > View Listings and available case explanations.",
        "Wait for Shared history verified; Pause and Resume retain completed reads.",
        "Repeat on each eBay account. The combined history is checked before copying Ready links.",
        "Open Existing Listings and choose Refresh Policy Checks to apply the shared incidents to a saved audit."
      ],
      "approvalStop": "Read-only on eBay. This workflow never relists, appeals, revises or ends a listing.",
      "output": "Private shared Policy Incidents history with account, SKU/ASIN, product, exact notice and source links. Exact ASINs block; related wording needs review, not a declaration of illegality.",
      "recovery": [
        "Use Sync Shared History after restoring the dashboard connection.",
        "A failed shared save stays local/queued and is not described as globally updated.",
        "An unavailable case retains its original row notice and a visible explanation-reading error."
      ],
      "evidence": "60 live incidents (56 ASINs) saved and read back from the deployed private dashboard; three case details read. Synthetic multi-page scanner and desktop/mobile UI checks pass. Full deployed multi-account validation remains pending."
    },
    {
      "id": "ops-health",
      "matrix": "F-02, F-11",
      "title": "Health & Installations",
      "status": "IMPLEMENTED, UNPROVEN",
      "summary": "Read workflow progress, review owners, installation files, and control pairing.",
      "prerequisites": [
        "Open the intended Chrome profile.",
        "The latest Windows helper is needed for inventory and pairing."
      ],
      "steps": [
        "Open Health & Installations from the popup.",
        "Check identity and running version.",
        "Refresh Status reads installed files and the public release.",
        "Open Results to review, pause, or resume a saved workflow.",
        "For background control, choose Pair This Profile, approve its code locally for the exact profile directory, then Check Pairing Approval."
      ],
      "approvalStop": "Pairing requires explicit local approval. No marketplace or spreadsheet action is approved here.",
      "output": "Profile-specific diagnostics. Other profiles' disk versions are not live runtime verification.",
      "recovery": [
        "Upgrade the one-time Windows helper if inventory or pairing is unavailable.",
        "Stale-progress warnings do not reset work.",
        "Queued sheet records are not confirmed saved."
      ],
      "evidence": "Deterministic lifecycle, status mapping, and pairing isolation checks. Signed-in deployment remains pending."
    },
    {
      "id": "setup",
      "matrix": "F-02, F-05, F-06, F-08, F-12",
      "title": "First-Time Setup",
      "status": "PARTIAL",
      "summary": "Configure one Chrome profile without guessing its marketplace identity.",
      "prerequisites": [
        "GLDN Ops is installed in the intended Chrome profile.",
        "The operator knows the Tasks-sheet computer label."
      ],
      "steps": [
        "Open the popup and choose only the computer label.",
        "Confirm the derived marketplace account, then click Save Computer.",
        "The included shared dashboard connection loads automatically. Existing saved connections are kept.",
        "Open Status and use Test Connection to verify server access; configured settings alone are not a successful connection.",
        "Use Optional Extension Setup for eComSniper downloads and Trackerbot store/sign-in.",
        "Run Feature Health Check and copy Settings Backup before a profile move."
      ],
      "approvalStop": "None. Setup must not start a marketplace workflow.",
      "output": "Saved computer/account mapping, dashboard connection, health report, and settings backup.",
      "recovery": [
        "If the account is wrong, correct the computer label instead of editing the derived account.",
        "Update & Reload restores a missing bundled default. Connect Dashboard remains available for an intentional override.",
        "Google Access denied requires checking the dashboard deployment; re-entering the same key does not prove access.",
        "Keep queued records until the dashboard confirms their receipt."
      ],
      "evidence": "v3.12.47 regression checks cover fresh-profile seeding, private/saved connection precedence and packaging. The existing endpoint returned Google HTTP 403 during release testing; live dashboard access remains unresolved."
    },
    {
      "id": "panel",
      "matrix": "U-01",
      "title": "Floating Panel",
      "status": "LIVE PASS",
      "summary": "Use the compact everyday controls without blocking marketplace pages.",
      "prerequisites": [
        "A supported eBay, Amazon, Poshmark, or Walmart page is open."
      ],
      "steps": [
        "On an eBay Order Details page, use the always-available panel for Prepare Order Note and daily actions.",
        "On eBay Listings pages, start a workflow or press Ctrl+Shift+G before expecting the panel; it stays hidden otherwise.",
        "Use Side to dock the panel to the right edge.",
        "Use the minus control to minimize it.",
        "Drag the resize handle while expanded.",
        "Open the three-dot settings menu to change theme, transparency, or reset layout.",
        "Use Stop Task for a safe checkpoint and Reset only for abandoned state.",
        "Use Reload Ext after local files are updated."
      ],
      "approvalStop": "Panel layout actions require no marketplace approval.",
      "output": "A saved per-profile panel mode, size, position, theme, and transparency.",
      "recovery": [
        "Use Reset panel layout if the panel is off-screen or awkwardly sized.",
        "Use Reload Ext when page controls are stale after an update.",
        "If eBay navigates without a full reload, GLDN Ops re-evaluates whether the panel belongs on the new page."
      ],
      "evidence": "Profile 2 proved Graphite at 75%, persisted resize, normal reload persistence, and right-edge docking. v3.11.46 adds contract coverage for always-visible eBay order details and workflow-gated Listings pages."
    },
    {
      "id": "dashboard",
      "matrix": "F-08, F-09",
      "title": "Dashboard and Sync Queue",
      "status": "PARTIAL",
      "summary": "Open shared results and retry records that could not sync immediately.",
      "prerequisites": [
        "The computer identity is saved and Status shows the dashboard is connected."
      ],
      "steps": [
        "Open Status in the popup.",
        "Click Test Connection.",
        "Click Open Dashboard to review saved results.",
        "If the popup reports queued records, click Retry Queued Dashboard Records.",
        "Confirm the sent and remaining counts."
      ],
      "approvalStop": "None. Dashboard reads and sync retries do not authorize marketplace actions.",
      "output": "A rendered dashboard plus idempotent sync receipts or a retained retry queue.",
      "recovery": [
        "Never clear queued data to hide a failure.",
        "Copy the diagnostic report if retries remain.",
        "Retry only after confirming whether the original sync ID already succeeded."
      ],
      "evidence": "Dashboard opening and the production queue timeout path are live-proven in Profile 2. One record queued, duplicate enqueue remained one, the same sync ID retried once through dashboard ping, and the final queue was zero. Drive proof: https://drive.google.com/file/d/1Hl_ro2zabXd7zJARXkijq7IT3W6AFW0y/view?usp=drivesdk"
    },
    {
      "id": "deployment",
      "matrix": "F-01, F-02, F-03, F-04, F-14",
      "title": "Local Update and Rollback",
      "status": "PARTIAL",
      "summary": "Update the unpacked local build while preserving settings and rollback data.",
      "prerequisites": [
        "The current extension folder is known.",
        "A settings backup has been copied.",
        "No marketplace confirmation dialog is active."
      ],
      "steps": [
        "Run Update-GLDN-Ops.cmd from the project folder.",
        "Wait for validation, snapshot creation, and matching-profile reload.",
        "Refresh active marketplace tabs.",
        "Confirm the panel and popup show the expected version.",
        "Run Feature Health Check.",
        "Use the local manager rollback only for a confirmed broken release."
      ],
      "approvalStop": "A real rollback in an active signed-in profile requires explicit approval because it changes runtime files.",
      "output": "Validated local files, preserved settings, a timestamped snapshot, and reloaded matching profiles.",
      "recovery": [
        "Do not use Chrome policy or a Web Store path for this local build.",
        "If validation fails, keep the current working files and copy diagnostics.",
        "Real Profile 2 rollback remains intentionally untested."
      ],
      "evidence": "Clean install/update fixtures pass. Another physical computer and a real Profile 2 rollback remain pending."
    },
    {
      "id": "mark-shipped",
      "matrix": "E-01",
      "title": "Mark as Shipped",
      "status": "PARTIAL",
      "summary": "Select every awaiting order, pause before activating eBay, stop again at eBay's final confirmation, and sync only an exact completion count.",
      "prerequisites": [
        "The signed-in eBay Awaiting shipment page is open.",
        "The complete Results total is visible."
      ],
      "steps": [
        "Click Mark as Shipped.",
        "Wait while GLDN Ops verifies every visible row, the master checkbox, and the awaiting total.",
        "Review GLDN's exact selected count and approve only the activation of eBay's Mark as shipped action.",
        "Review eBay's own confirmation count.",
        "Approve eBay's final confirmation button only when the selected count equals the intended awaiting total.",
        "After approval, wait for eBay success and zero remaining results.",
        "Confirm the dashboard and matching Tasks checkbox update."
      ],
      "approvalStop": "STOP before activating eBay and STOP again at eBay's final confirmation. Each action requires explicit approval for the exact count shown.",
      "output": "Exact awaiting, selected, shipped, remaining, status, dashboard history, and Tasks completion.",
      "recovery": [
        "If eBay omits a confirmation number, GLDN Ops may reuse only the exact pre-confirm count.",
        "Any count mismatch stops safely.",
        "The first approved eBay Mark as shipped activation uses one trusted, hit-tested Chrome press/release; it never retries or clicks a second target.",
        "The Profile 2 local control may activate an already-open GLDN review only with the exact live-count token. A separate APPROVE EBAY CONTINUE N token is required for one trusted press/release on eBay's exact reviewed final button.",
        "A stale, duplicate, wrong-tab, wrong-page, changed-count, changed-label, ambiguous target, or failed hit-test request stops without another click.",
        "Updating to a new extension version clears an unfinished Mark as Shipped run from the older extension context.",
        "Copy diagnostics before Reset if the confirmation remains stale."
      ],
      "evidence": "Profile 2 previously completed 3 of 3 orders and read back zero remaining plus exact dashboard and Tasks rows. Computer 2 / FANCYFI on v3.11.33 verified 4 of 4 selections but exposed that the synthetic first activation did not open eBay's confirmation. v3.11.34 replaces that activation with one trusted exact-count, exact-tab, exact-page, hit-tested press/release and passes the complete 309-test JavaScript suite. A signed-in Computer 2 completion and dashboard/Tasks readback remain required."
    },
    {
      "id": "ebay-note-profit",
      "matrix": "E-04, E-05",
      "title": "eBay Order Note and Profit",
      "status": "PARTIAL",
      "summary": "Draft an eBay note visibly on Order Details, or use the separate exact-order workflow for verified profit.",
      "prerequisites": [
        "Open the matching eBay Order Details page.",
        "For automatic profit, use the exact Amazon order-details card and a matching EcomSniper Custom label SKU; checkout information is only a draft."
      ],
      "steps": [
        "On Amazon, click Review & Copy Amazon Info. Selected Arriving by/on dates populate ETA, including dates loaded after the review opens; manual ETA edits are preserved.",
        "Verify total, ETA and profile, then click Copy Amazon Info. For verified profit, also verify order ID, exact ASIN and item-cost evidence on Amazon order details.",
        "For a manual draft, use the GLDN Order Note box under the eBay Order details heading, even when the side panel is collapsed. Click Use copied Amazon info or paste the copied information into Editable note.",
        "Edit the note as needed, check the buyer, address and item against Amazon, tick the confirmation, then click Fill eBay note.",
        "Review the native eBay textarea and click Save only when correct. The draft path does not sync profit.",
        "For verified profit instead, use Prepare Order Note in the GLDN panel, confirm the exact ASIN match, and click Fill Add Note Box or Fill Edit Note Box.",
        "Review and manually save the verified note, then confirm one dashboard profit row."
      ],
      "approvalStop": "STOP at eBay Save. Saving the note requires explicit action-time approval.",
      "output": "An editable note draft with manual eBay Save and no profit sync, or a separately verified saved note plus one upserted profit row.",
      "recovery": [
        "Known mismatched ASINs or copied information older than one day cannot be imported into a draft. Manually review missing ASINs against the buyer, address and item.",
        "Across Chrome profiles, paste Copy Amazon Info into Editable note; profile-local saved handoffs are not shared.",
        "Changing the eBay order clears the draft and its review checkbox.",
        "Checkout, product-page, stale, wrong-order, or mismatched-ASIN evidence remains ineligible for verified profit.",
        "If no verified handoff is ready, use Prepare Order Note's recovery window to review the exact Amazon order.",
        "eBay Save remains manual; the draft path never syncs profit.",
        "An already matching verified saved note may refresh the same profit row without another Save."
      ],
      "evidence": "Historical Profile 2 proof covers exact-order note and profit sync. Current read-only M0/M8 diagnosis found dozens of unrelated IDs for one item. v3.12.51 scopes shipment IDs, isolates checkout/tab caches, rechecks Copy, normalizes duplicates and preserves true mismatch blocking. Focused and synthetic desktop/mobile checks pass with zero native Save or profit sync. Refresh both tabs after updating and copy again; old polluted handoffs are not repaired. Refreshed signed-in post-fix validation remains pending."
    },
    {
      "id": "ebay-monthly-profit",
      "matrix": "E-14",
      "title": "eBay Profit Audit",
      "status": "PARTIAL LIVE",
      "summary": "Read one eBay order month or all available history, calculate Saved-note profit from the note alone, and separately calculate Independent Amazon profit from visible eBay earnings plus exact Amazon order-item costs.",
      "prerequisites": [
        "Use the Chrome profile already signed into the intended eBay account for order collection.",
        "The saved computer identity must map to that eBay account.",
        "Set one permanent Amazon profile name in Setup in every Chrome profile used for cost reconciliation.",
        "Orders count as saved-note exact only when their existing eBay note follows earnings - Amazon cost - Amazon profile - ETA, or an ambiguous amount has been explicitly confirmed inside GLDN Ops."
      ],
      "steps": [
        "Open Workflows in the eBay Chrome profile and click Open eBay Profit Audit.",
        "Choose One month for a smaller audit or All available history for the full available eBay history range.",
        "For One month, choose the calendar month and click Read Month. For all history, click Read All History.",
        "Let the one inactive signed-in eBay worker index the selected range and open each exact order detail.",
        "Read Saved-note profit separately: saved-note earnings minus saved-note Amazon cost.",
        "Use the coverage count to see how many reviewed orders are included. Pending means no confirmed saved-note profit exists; a dollar result with incomplete coverage is a partial total.",
        "Review Independent Amazon profit separately after sync: visible eBay earnings minus an exact matched Amazon order-item cost.",
        "Allow GLDN Ops to normalize harmless money formatting mistakes. When it flags an ambiguous character, likely missing decimal, or earnings mismatch, edit the suggested values and click Confirm note amounts.",
        "Keep missing notes, unconfirmed ambiguous amounts, missing earnings, and date mismatches outside confirmed saved-note totals.",
        "Type the displayed APPROVE SYNC EBAY YYYY-MM N token for a month or APPROVE SYNC EBAY ALL N for all history only after reviewing the exact unsynced row count.",
        "Confirm dashboard delivery or a retained retry queue, then read back the computer profit sheet.",
        "In an Amazon Chrome profile, verify its permanent Amazon profile name in Setup and click Resolve eBay Amazon Costs for the corresponding unresolved rows.",
        "Review the exact supplier profile, exact matches, misses, and live pending count. Click Save Cost Resolution Results once; GLDN Ops binds that explicit action to the unchanged live count.",
        "Wait for the visible Results Saved or Results Queued Safely receipt before leaving the page.",
        "Move to each other signed-in Amazon Chrome profile and repeat. Rows already attempted by that named profile are excluded; unresolved rows remain open without becoming zero.",
        "Compare Saved-note profit and Independent Amazon profit in the shared reconciliation sheet. Missing SKU and substituted-item cases remain manual review."
      ],
      "approvalStop": "STOP at both reviews. The eBay write requires APPROVE SYNC EBAY YYYY-MM N for a month or APPROVE SYNC EBAY ALL N for all history. Each independent Amazon-profile result requires APPROVE RESOLVE EBAY COSTS N. Neither approval changes an eBay order, listing, or Amazon order.",
      "output": "A resumable selected-range checkpoint; visibly covered Saved-note earnings, cost, and profit; separate Independent Amazon earnings, cost, and profit; discrepancy status; attempted supplier profiles; and a durable unresolved queue.",
      "recovery": [
        "A deliberate Pause closes only the worker tab and preserves the exact checkpoint.",
        "A page-verification failure leaves the exact failed eBay tab open and changes the run to Paused with the real reason.",
        "Resume reuses a preserved failed worker or recreates one inactive worker when the old tab no longer exists.",
        "The final eBay page remains open at review and closes only after the selected range is fully synced or explicitly reset.",
        "An extension update pauses an in-progress run instead of mixing versions.",
        "Never guess a missing Amazon cost or substitute a current product price.",
        "Deterministic note formatting cleanup may be automatic, but uncertain dollar values require editable operator confirmation before entering confirmed totals.",
        "Confirming note amounts changes only GLDN Ops internal evidence and never edits the saved eBay note.",
        "Do not rename an Amazon profile after it has recorded attempts; use the same permanent label on that Chrome profile.",
        "The eBay Profit Audit page can correctly say No saved run in an Amazon-only Chrome profile; the eBay checkpoint remains local to the eBay Chrome profile and Amazon reconciliation receipts are written to the shared sheet.",
        "Copy diagnostics if eBay or Amazon changes its order-row, period control, Custom date range, or order-detail layout."
      ],
      "evidence": "The signed-in July 2026 eBay month and approved Amazon-profile reconciliations remain historical live evidence. v3.12.24 adds deterministic all-history range, year-rollover, per-order month preservation, clear coverage, Pending-state, and partial-profit contracts. A signed-in all-history live run remains pending."
    },
    {
      "id": "order-placement-audit",
      "matrix": "E-13",
      "title": "Order Placement Audit",
      "status": "PARTIAL LIVE",
      "summary": "Compare unit-level eBay demand with exact ASIN purchases found across every signed-in Amazon Chrome profile, then flag duplicate, extra, canceled-order, and missing purchases without changing either marketplace.",
      "prerequisites": [
        "Finish the Monthly eBay Profit read for the same computer, eBay account, and month so exact order numbers, dates, ASINs, quantities, statuses, and ship-to evidence are available.",
        "Set one permanent Amazon profile name in Setup in every Chrome profile used to place orders.",
        "List every expected Amazon profile name on the audit page so cross-profile completion can be proven.",
        "The shared dashboard connection must work in every participating Chrome profile."
      ],
      "steps": [
        "Open Order Placement Audit from the eBay Chrome profile.",
        "Choose the computer and eBay order month, enter every Amazon profile expected on that computer, and click Build From Completed eBay Month.",
        "Review the exact eBay unit count. Rebuilding this demand deliberately clears prior Amazon scans for that computer, account, and month.",
        "Open GLDN Ops in the first signed-in Amazon Chrome profile, open Order Placement Audit, choose the same computer and month, and click Scan This Signed-In Amazon Profile.",
        "Let the one inactive Amazon worker index order history and read only matching exact-ASIN order details.",
        "Wait until that profile shows review/completed and appears as scanned in Profile coverage.",
        "Repeat the same scan from every other signed-in Amazon Chrome profile used on that computer. The shared audit deduplicates an Amazon order that is visible in more than one Chrome profile.",
        "Review Duplicate, same recipient first; then Possible extra purchase, Purchased after cancel, and Missing Amazon purchase.",
        "Use the exact eBay and Amazon links to verify any flagged unit, and download the CSV for a retained audit copy."
      ],
      "approvalStop": "None. This workflow is read-only. It never cancels, refunds, marks shipped, purchases, edits, or deletes an eBay or Amazon order. Any corrective marketplace action must be handled separately with its own exact approval.",
      "output": "A shared computer/account/month audit with expected eBay units, Amazon purchase units, scanned-profile coverage, exact same-recipient duplicates, possible different-recipient extras, canceled-order purchases, unmatched demand, source links, and CSV export.",
      "recovery": [
        "Google Access Denied can mean the dashboard owner must renew the existing Google authorization; entering the same setup key does not fix it.",
        "Build is available only for a completed read matching the selected computer, account and month. Open Monthly eBay Profit in the eBay Chrome profile if it is missing.",
        "An Amazon-only profile does not need its own eBay read. Use Refresh Results after the eBay profile builds the shared demand.",
        "Incomplete or mismatched demand blocks scanning; rebuild it from the exact completed eBay read.",
        "Pause stops at the next Amazon page checkpoint; Resume continues the saved profile scan.",
        "If the inactive worker closes or a page cannot be verified, the checkpoint remains resumable in that same signed-in Chrome profile.",
        "Reset This Profile Scan clears only that Chrome profile's local checkpoint; completed shared results from other profiles remain saved.",
        "Save Profile List updates the expected-profile checklist without erasing completed scans.",
        "Do not call a different-recipient purchase an exact duplicate unless total Amazon units exceed total eBay demand for the ASIN.",
        "A canceled eBay order with no Amazon purchase is clean; a matched purchase for a canceled or refunded order is flagged.",
        "Missing Amazon purchase remains open until all expected Amazon profiles have been scanned."
      ],
      "evidence": "Deterministic unit-allocation tests cover exact matches, same-recipient duplicates, different-recipient extras, two legitimate customers sharing one ASIN, quantities, canceled orders, active-before-canceled allocation, missing purchases, and cross-profile deduplication. Signed-in Profile 2 seeded 101 July 2026 eBay units, preserved all 101 through an extension reload, and scanned 10 Amazon order-history pages for profile F9132 across 83 exact ASIN targets. That profile returned zero matching purchases; one exact target ASIN was also visibly searched in the signed-in Amazon account and returned no result. The remaining Amazon profiles have not been scanned, so the complete cross-profile audit is not LIVE PASS."
    },
    {
      "id": "seller-metrics",
      "matrix": "E-02, T-01, T-02, T-03",
      "title": "Seller Level and Tasks Metrics",
      "status": "LIVE PASS",
      "summary": "Read four seller metrics, review them, and update the correct Tasks computer column and warnings.",
      "prerequisites": [
        "The signed-in eBay seller performance page is open.",
        "The correct computer identity is saved."
      ],
      "steps": [
        "Click Scan Seller Level.",
        "Review transaction defects, late shipment, tracking, unresolved cases, seller level, and evaluation date.",
        "Click Save Seller Level Check.",
        "Confirm all four metrics receive timestamp notes in the correct Tasks computer column.",
        "Confirm the parent performance checkbox updates only after all four metrics save.",
        "Review CHECK warnings and threshold colors."
      ],
      "approvalStop": "Saving reviewed metrics needs operator confirmation in the review window but performs no marketplace write.",
      "output": "Dashboard current/history rows, Tasks metric values and notes, parent checkbox, and CHECK warnings.",
      "recovery": [
        "Missing values remain Not detected and must not become zero.",
        "Poshmark-only columns stay grey and empty.",
        "Copy diagnostics if the review values do not match eBay."
      ],
      "evidence": "Exact Profile 2 values, dashboard rows, Tasks H14:H18, grey Poshmark-only cells, and threshold boundaries are live-proven."
    },
    {
      "id": "listing-limits",
      "matrix": "E-03",
      "title": "Confirm Listings Under Limit",
      "status": "LIVE PASS",
      "summary": "Evaluate Store insertion allowance, seller quantity, and seller dollar limits independently, preserving near-limit warnings without confusing them with a reached hard cap.",
      "prerequisites": [
        "Seller Hub Overview is fully loaded.",
        "The Store plan and monthly dollar limit are saved."
      ],
      "steps": [
        "Click Confirm Listings Under Limit.",
        "Review active listings and available quantity as inventory information only.",
        "Review Store allowance used/left.",
        "Review seller quantity used/limit.",
        "Review seller dollar used/limit.",
        "Click Confirm Listings This Month only when all detected values match eBay."
      ],
      "approvalStop": "The review confirmation is required; it does not change listings.",
      "output": "Monthly confirmation, dashboard history, and the matching Tasks completion row.",
      "recovery": [
        "Never treat active listings as the Store insertion allowance.",
        "A 95% warning may remain visible while Under limit is still YES.",
        "Missing Store allowance or seller-dollar data cannot check the task.",
        "Reopen Seller Hub Overview if a card is incomplete."
      ],
      "evidence": "Production dashboard @38 separates near-limit warnings from hard-cap completion. The focused v3.11.29 contract passes 7/7 and the complete release gate passes 269/269. Signed-in Profile 2 retained the 98.79% warning while Tasks H20 checked with Under limit: YES; Sync Receipts row 84 confirms taskChecked true."
    },
    {
      "id": "amazon-subscribe-save",
      "matrix": "A-01",
      "title": "Cancel Amazon Subscribe & Save",
      "status": "LIVE PASS",
      "summary": "Scan only real active subscriptions for the current signed-in Amazon Chrome profile, including additional carousel cards and distinct duplicate products; exclude recommendations, require exact-count approval, cancel the reviewed set one at a time, and prove zero remain.",
      "prerequisites": [
        "The intended Amazon account is signed in in this Chrome profile.",
        "The correct Tasks computer identity is saved.",
        "Repeat the workflow separately in every Chrome profile that uses a different Amazon account."
      ],
      "steps": [
        "Open the popup and click Open Amazon Subscribe & Save.",
        "Let GLDN Ops open Manage Your Subscriptions and settle the complete page.",
        "On Amazon's newer layout, confirm All addresses is the selected scope; on the older layout, confirm the active-subscription total.",
        "Review the exact list under Your Subscriptions. Additional carousel cards and separate subscriptions for the same product remain separate. Recommended for you, Subscribe now, Add new subscriptions, and Buy it again are excluded.",
        "Type the exact count-bound token shown only when every reviewed item should be cancelled.",
        "After approval, GLDN Ops opens each reviewed subscription, clicks Cancel subscription, verifies Amazon's Cancel your subscription? dialog, leaves the optional reason unchanged, and uses Cancel my subscription once.",
        "Wait for Cancellation Confirmed after each item.",
        "Let GLDN Ops return to the manager and run a final zero-active scan.",
        "Confirm the current-profile proof in Amazon Subscribe Save History.",
        "Repeat in every other signed-in Amazon Chrome profile. A current-profile proof does not check the ALL Amazon Accounts task."
      ],
      "approvalStop": "STOP before any cancellation. The exact token APPROVE CANCEL SUBSCRIPTIONS N authorizes only the unchanged reviewed set of N subscriptions; no Amazon cancellation control is clicked before that token is accepted.",
      "output": "Exact scanned and cancelled counts, per-profile scope, zero-active proof, local result, and one shared current-profile audit row. The all-accounts Tasks checkbox remains separate.",
      "recovery": [
        "If Amazon shows sign-in, CAPTCHA, a different count, an unloaded card, or an unknown final result, GLDN Ops stops without retrying the irreversible click.",
        "Never treat Recommended for you or Subscribe now cards as subscriptions.",
        "A zero result in one Amazon profile does not prove another Chrome profile/account is clear and cannot check the ALL Amazon Accounts task.",
        "Copy diagnostics before Reset when a final cancellation result is uncertain."
      ],
      "evidence": "The updated V2 tutorial was reviewed end to end. It confirms the exact Your Subscriptions > subscription details > Cancel subscription > Cancel your subscription? > Cancel my subscription > Cancellation Confirmed sequence, optional reason behavior, carousel cards, duplicate-looking subscriptions, recommendation exclusion, and separate Chrome-profile repetition. Signed-in Profile 2 has live-proven the zero-active current-profile path; a nonzero destructive run still requires a fresh exact-count approval."
    },
    {
      "id": "ebay-snapshot",
      "matrix": "E-06",
      "title": "eBay Sales Snapshot",
      "status": "LIVE PASS",
      "summary": "Capture sales, traffic, advertising, and feedback with card-scoped values.",
      "prerequisites": [
        "Seller Hub Overview cards are visible."
      ],
      "steps": [
        "Click Scan Sales Snapshot.",
        "Review sales today, 7, 31, and 90 days plus change direction.",
        "Review traffic impressions and page views.",
        "Review advertising values that eBay actually displays.",
        "Review positive, neutral, and negative feedback counts.",
        "Click Save eBay Snapshot only when the review matches the page."
      ],
      "approvalStop": "The review save needs confirmation but performs no marketplace write.",
      "output": "Dashboard snapshot and history rows for the saved computer/account.",
      "recovery": [
        "A missing card stays blank instead of borrowing a nearby number.",
        "Reload Seller Hub once if cards are incomplete.",
        "Do not invent ad cost when eBay does not display it."
      ],
      "evidence": "Profile 2 source, review, dashboard, history, and receipt values are live-proven."
    },
    {
      "id": "store-categories",
      "matrix": "E-07",
      "title": "Store Category Configuration",
      "status": "LIVE PASS",
      "summary": "Save exact source and destination Store categories per eBay account.",
      "prerequisites": [
        "The intended eBay account is signed in.",
        "Exact Store category names are known."
      ],
      "steps": [
        "Open Store Categories from the eBay panel settings or popup Settings.",
        "Confirm the displayed eBay account.",
        "Enter exact source category names and one exact destination name.",
        "Optionally enter numeric source IDs and backburner item IDs.",
        "Click Save and Verify.",
        "Copy a category/settings backup before moving computers or profiles."
      ],
      "approvalStop": "Saving configuration changes extension settings only and must not launch a listing workflow.",
      "output": "Validated, account-bound category names, IDs, and backburner IDs preserved across updates.",
      "recovery": [
        "Duplicate, overlapping, malformed, or empty settings fail closed.",
        "Restore only a backup for the same account.",
        "Recheck exact category names after eBay renames a Store category."
      ],
      "evidence": "Profile 2 FAK12 exact categories, IDs, backup, restore, and reload persistence are live-proven."
    },
    {
      "id": "move99",
      "matrix": "E-08",
      "title": "Move .99 Listings Into Sale",
      "status": "LIVE PASS WITH BOUNDARY",
      "summary": "Scan exact item IDs, select only exact .99 listings, change only primary Store category, and pause before Submit.",
      "prerequisites": [
        "Exact source/destination categories are saved for the signed-in eBay account.",
        "The operator has reviewed any backburner exclusions.",
        "No other Move .99 run is active."
      ],
      "steps": [
        "Open Workflows in the popup and click Open Move .99 Workflow.",
        "Wait for the complete filtered Active Listings exact-ID scan.",
        "Review total scanned, qualifying, omitted, and failed counts.",
        "Apply only the verified exact-ID batches, each capped at 500.",
        "Confirm eBay's native selected count matches the intended batch.",
        "Confirm only Primary Store category changed to the exact destination.",
        "Approve Submit only for the exact reviewed batch.",
        "After the approved final eBay Submit, let the workflow stop while eBay propagates the category changes.",
        "Start a later deliberate run for any saved remaining batches only after eBay has finished updating listings."
      ],
      "approvalStop": "STOP before every eBay Submit. Each exact batch requires separate action-time approval.",
      "output": "The exact submitted batch, propagation-pending status, saved remaining-batch count, and audit data. Tasks completion still requires a later exact zero-remaining and zero-failed proof.",
      "recovery": [
        "Any incomplete scan, mixed price, selected-count mismatch, missing picker, or uncertain submit result stops safely without opening another tab or batch.",
        "A completed Submit is terminal for that run: GLDN Ops must not reopen Active Listings, rescan, or create another workspace while eBay propagates changes.",
        "If the review page disappears before a trusted Submit click, the run enters Approval Lost and requires manual reconciliation.",
        "Do not alter item specifics to force category failures through.",
        "Six known FAK12 failures remain backburnered and must not be resubmitted without new approval."
      ],
      "evidence": "Profile 2 moved 2,564 successful exact .99 listings in earlier approved batches and isolated six persistent backburner failures. The v3.10.4 read-only retest scanned 232 listings over two pages, staged 5 exact matches, and held the same Submit (5) workspace through extension reload and repeated approval checks with no new tab; Submit remained untouched. Formal Drive video is pending."
    },
    {
      "id": "reverse99",
      "matrix": "E-09",
      "title": "Move Non-.99 Listings Out of Sale",
      "status": "IMPLEMENTED, UNPROVEN",
      "summary": "Require the sale event to be off, then find valid non-.99 prices in the sale category and return them to the configured non-sale category.",
      "prerequisites": [
        "The sale and non-sale categories are configured for the signed-in account.",
        "The sale event is turned off before scanning displayed prices.",
        "Backburner exclusions are current."
      ],
      "steps": [
        "Open Workflows and click Move Non-.99 Out of Sale.",
        "Answer whether the sale event is active.",
        "If Sale Event Is ON, stop and turn the sale event off; GLDN Ops must not start a scan.",
        "Choose Sale Event Is OFF only after confirming it is off.",
        "Review the complete sale-category scan summary.",
        "Confirm every selected listing has a valid non-.99 price.",
        "Confirm backburner items are excluded.",
        "Verify only Primary Store category changes to the configured non-sale destination.",
        "Approve the exact final Submit.",
        "Let the workflow stop while eBay propagates the category changes.",
        "Start a later deliberate run for any saved remainder only after eBay has finished updating listings."
      ],
      "approvalStop": "STOP before every eBay Submit and approve only the exact reviewed count.",
      "output": "The exact submitted batch, propagation-pending status, saved remaining-batch count, and audit data.",
      "recovery": [
        "Sale Event Is ON, a closed prompt, or an unconfirmed answer blocks before workflow reservation, tab creation, or scanning.",
        "Missing or ambiguous prices are excluded.",
        "A completed Submit is terminal for that run and cannot automatically rescan or create another workspace.",
        "Any uncertain pre-submit state returns to read-only reconciliation.",
        "Do not use the reverse workflow on Poshmark."
      ],
      "evidence": "v3.11.30 adds the fail-closed sale-event gate to the popup, internal starter, eBay panel, background launcher, and saved-state runner. Automated contracts prove only an explicit Sale Event Is OFF answer can start the reverse workflow. The live ON-path block is the required signed-in gate; the OFF-path scan must wait until the sale event is actually off."
    },
    {
      "id": "ebay-variations",
      "matrix": "E-11",
      "title": "Find and End Variation Listings",
      "status": "IMPLEMENTED, LIVE REVIEW PENDING",
      "summary": "Scan every eBay Active Listings page automatically, use eBay's signed-in read-only End review to identify exact variation parents, and prepare durable approval-gated End batches.",
      "prerequisites": [
        "The intended eBay account is signed in in this Chrome profile.",
        "No other GLDN Ops workflow or variation review is active.",
        "Keep the Variation Listings extension page open while the account-wide scan runs."
      ],
      "steps": [
        "Open Workflows and click Find / End Variation Listings.",
        "Click Scan & Prepare Review; no report download or CSV import is required.",
        "GLDN Ops opens one inactive signed-in eBay tab and verifies every 200-row Active Listings page by exact item number.",
        "GLDN Ops checks exact IDs through eBay's read-only End review in batches of at most 200 and keeps only listings eBay identifies as true variation parents.",
        "Review the searchable variation-parent table and download the audit CSV if a permanent copy is needed.",
        "GLDN Ops automatically prepares the first exact batch of at most 200 parent listings and opens eBay's visible Bulk Edit review.",
        "Inspect every visible eBay row and return to Variation Listings.",
        "Type APPROVE END VARIATIONS N only after the exact batch count and rows are correct.",
        "Wait for eBay's exact success and failure counts. Successful IDs become Ended, disappear from the remaining set, and the next review is prepared automatically.",
        "Give a new exact approval for every remaining batch. After the final result, run Scan & Prepare Review again for a fresh zero-variation verification."
      ],
      "approvalStop": "STOP before every eBay End action. The exact token APPROVE END VARIATIONS N must match the current verified batch and eBay's displayed count; preparing or viewing a review is never approval.",
      "output": "An automated account-wide exact-ID scan, searchable variation-parent audit, exportable CSV, exact eBay review batches, durable completion ledger, exact approval receipts, and remaining count.",
      "recovery": [
        "A missing page range, incomplete row count, duplicate item number, changing Active Listings total, browser check, or classification mismatch stops with no listing changes.",
        "Every active listing must be accounted for before any variation parent is accepted.",
        "No more than 200 parent listings can enter one End review.",
        "A missing or mismatched eBay count blocks approval.",
        "An unfinished exact review can be reopened from the Variation Listings page.",
        "GLDN Ops may prepare the next review after a proven successful result, but it never ends that batch without a new exact approval token."
      ],
      "evidence": "The exact ending path is already live-proven in signed-in Profile 2 across 736 parents: eBay reported 200 already ended, then 200 of 200, 200 of 200, and 136 of 136 successful with zero failures. v3.11.48 replaces manual report generation and import with an automated complete-page scan, eBay-confirmed variation classification, and a Profile 2 launch path that stops at the same exact approval review. Current-version signed-in read-only review proof is required before release."
    },
    {
      "id": "existing-listings-policy-audit",
      "matrix": "E-12",
      "title": "Existing Listings Policy Audit",
      "status": "IMPLEMENTED, LIVE REVIEW PENDING",
      "summary": "Scan existing listings and end selected flags in exact, approved batches.",
      "prerequisites": [
        "The intended eBay account is signed in in this Chrome profile and its computer identity is saved.",
        "No other GLDN Ops scan or marketplace review is active.",
        "The bundled reviewed Listing Preflight rule pack is present. Dashboard setup is optional for listing checks."
      ],
      "steps": [
        "Open Workflows, Listings, then Scan Existing Listings.",
        "Start or Resume a scan; Refresh Policy Checks reclassifies saved rows with current rules without rescanning.",
        "If shared history is unavailable, the scan still uses built-in rules and saved incidents. The warning means newer incidents from other profiles may be missing, not that the scan is blocked.",
        "Inspect matched reasons. Review is not a confirmed violation; ordinary brand names alone are not flags.",
        "The default Block + Review view shows both types together. Rows per page defaults to All; choose 100, 250 or 500 for smaller pages. Select All Block + Review selects both across every page; the header checkbox selects the displayed result set.",
        "Use individual checkboxes or Select Filtered Flags for a narrower selection. Already-ended, unconfirmed-batch and no-match items cannot enter a new End batch.",
        "Review Selected on eBay opens up to 200 exact listings together. Inspect this batch before approval.",
        "Either return to GLDN, type the exact displayed phrase and click End Exact Batch, OR use eBay's own End confirmation after reviewing the rows. Do not submit through both paths.",
        "If you ended directly on eBay, use Check eBay Result in GLDN. No second End approval is needed to check results.",
        "If some results remain unconfirmed, choose Set Aside Batch & Continue. Those exact items stay excluded while you select and review other Block or Review flags.",
        "After verified success, ended counts update and remaining selection stays queued. Each next batch needs fresh approval."
      ],
      "approvalStop": "No scan changes listings. Exact, one-use approval is required for each reviewed batch.",
      "output": "Exact-ID audit, bulk selection, native batch review, verified ended counts, remaining selection and CSV.",
      "recovery": [
        "Count changes produce coverage warnings, not automatic restarts.",
        "Refresh Policy Checks keeps scan dates and ended counts. Audits older than 48 hours require a fresh scan before ending.",
        "Check eBay Result reads exact normal eBay pages and saves each proven ended item. Hidden policy-violation rows are not counted as ended.",
        "Set-aside batches remain available under Check Saved Batch Result, including after a new scan. Checking one does not cancel another current review.",
        "Updates preserve native batch evidence, not old approval permission. When updating from v3.12.38, do not Reset or discard the stuck review first. If the extension blocks its own updater, run the existing GLDN Ops installer/update tool, then reload GLDN Ops using Chrome's extension management page and reopen the audit.",
        "Pesticides and aerosol spray cans stay excluded. Specific conditional risks stay Review. No-match is not a policy guarantee."
      ],
      "evidence": "v3.12.41 unit and isolated Chrome checks cover All-row display, optional pagination, preserved selections, combined Block + Review display, mixed 200-plus-1 batches, and ended/unconfirmed exclusions. Existing native completion recovery is retained. No live End action performed."
    },
    {
      "id": "move99-recovery",
      "matrix": "E-10",
      "title": "Move Category Recovery",
      "status": "LIVE PASS",
      "summary": "Recover from reloads, picker delays, lost approval pages, and per-item failures without guessing.",
      "prerequisites": [
        "A saved Move .99 checkpoint exists.",
        "The same signed-in eBay account and configured categories are active."
      ],
      "steps": [
        "Reload the extension only when the current page is stable.",
        "Use Run Move .99 or Apply to reclaim the verified checkpoint.",
        "If the approval page or submission outcome is uncertain, keep the run stopped and manually reconcile the saved batch before starting another scan.",
        "Review processed, failed, remaining, and recovery history.",
        "Export audit data before Reset.",
        "Use Retry Failed Only only with a new explicit approval."
      ],
      "approvalStop": "Recovery never grants Submit approval. Retrying or submitting any remaining item requires a new action-time approval.",
      "output": "Idempotent checkpoint, reconciliation result, processed/failed lists, and audit export.",
      "recovery": [
        "Generic or non-numeric Store category tokens are rejected.",
        "Never shift the saved page after eBay omits a row.",
        "When outcome is unknown, do not auto-rescan, navigate, or open another workspace; reconcile first and then start a new operator-approved scan."
      ],
      "evidence": "Profile 2 recovered a cancelled review into a complete read-only scan and exported exact Remaining / Retry rows with zero batches submitted."
    },
    {
      "id": "ecomsniper-handoffs",
      "matrix": "C-01, C-02, C-04",
      "title": "EcomSniper Handoffs and Status",
      "status": "LIVE PASS",
      "summary": "Verify GLDN seller-extraction counts and handoff-tab state without claiming that GLDN runs or reads EcomSniper Bulk Poster.",
      "prerequisites": [
        "eBay and EcomSniper are signed in in the same Chrome profile.",
        "EcomSniper's visible Extract Sellers control is present on an eBay search-results page for seller extraction."
      ],
      "steps": [
        "Open Workflows and review EcomSniper Handoffs.",
        "Use Open EcomSniper Competitor Scanner or Filter Titles & Open Product Hunter only for the handoff you intend.",
        "Click Refresh Status to read current GLDN-observable state.",
        "Treat Extracting as seller extraction on eBay only; confirm the before total, after total, and reported new count reconcile.",
        "Treat Handoff open or Handoff closed as tab-lifecycle information only.",
        "Do not infer Bulk Poster progress, item counts, completion, or failure from the handoff monitor.",
        "Use Stop GLDN Assist to request a safe stop of GLDN's seller-extraction queue; stop EcomSniper work from EcomSniper itself."
      ],
      "approvalStop": "GLDN Ops cannot approve or click EcomSniper's private Scanner, Product Hunter, export, Bulk Poster, or listing controls. Any listing action requires explicit approval.",
      "output": "Verified seller-count progression plus honest open, closed, stopped, or unknown handoff state.",
      "recovery": [
        "Missing, stale, wrong-page, mismatched, or timed-out seller counts stop safely.",
        "An open or closed private EcomSniper tab never proves processing completion.",
        "Copy the full diagnostic report before Reset.",
        "No Windows local helper is required."
      ],
      "evidence": "Profile 2 previously reconciled seller extraction from 892 to 1,607. Signed-in Profile 2 then live-proved the exact Competitor Scanner and Product Hunter routes, open-state readback, lifecycle-only scope, and Stop closing only the GLDN-opened Product Hunter tab. GLDN made no private-processing claim and performed zero marketplace actions."
    },
    {
      "id": "listing-preflight",
      "matrix": "C-05",
      "title": "Listing Policy Check",
      "status": "IMPLEMENTED, LIVE REVIEW PENDING",
      "summary": "Paste product titles or Amazon links, read exact product text automatically, and keep known prohibited or restricted items out of Bulk Poster.",
      "prerequisites": [
        "Open Listing Policy Check from Workflows > Research.",
        "Be signed into Amazon in this Chrome profile when raw Amazon links need to be read.",
        "Dashboard setup is optional. Without shared history, built-in rules and saved incidents still apply; newer incidents from other profiles may be missing."
      ],
      "steps": [
        "Open Listing Policy Check; no copied links are required for the page to open.",
        "Paste one Amazon link, product title, ASIN with title, or CSV row per line.",
        "Select Check Items. Raw Amazon links are read sequentially in one inactive Amazon tab and cached for safe resume.",
        "If Amazon displays a CAPTCHA, complete it in the preserved worker tab and select Check Items again.",
        "Review Needs review and Blocked rows. Pesticides and spray cans always Block; brand names alone do not stop products.",
        "Copy Ready Links or Copy Ready & Open Bulk Poster. Review and Blocked rows are excluded.",
        "Perform final human review of the exact generated listing before any listing action."
      ],
      "approvalStop": "Listing Policy Check is read-only and never authorizes or submits an eBay listing.",
      "output": "A simple Ready, Needs review, and Blocked table plus a copyable Ready-only Amazon-link list.",
      "recovery": [
        "If the policy pack is empty, stale, invalid, or unavailable, every input stays in Needs review.",
        "If Amazon shows a robot or CAPTCHA page, solve it in the saved worker tab and resume.",
        "Completed product reads are cached for seven days so a paused or interrupted list can continue.",
        "A Ready result means no published item-policy keyword matched; it is not eBay approval."
      ],
      "evidence": "The 2026-09-13.1 shared pack contains 622 rules: 618 official-policy decisions, 2 GLDN operator Blocks for pesticides and spray cans, and 2 Discord-backed Review warnings. Only IP was re-reviewed on September 13; the full policy-hub review date remains August 31. Text screening cannot verify product authenticity, image rights or licensing."
    },
    {
      "id": "product-hunter-listing-guard",
      "matrix": "C-06",
      "title": "Product Hunter Active Listing Guard",
      "status": "IMPLEMENTED, LIVE REVIEW PENDING",
      "summary": "Build a verified read-only index of one eBay computer's complete Active Listings inventory and prevent Product Hunter from returning products that are already active.",
      "prerequisites": [
        "Load the separate GLDN Product Hunter extension in the Chrome profile signed into the intended eBay account and Amazon.",
        "Choose one of the five eBay computers: M0, 2, 6, 0, or M1."
      ],
      "steps": [
        "Open GLDN Product Hunter and select Open Product Hunter.",
        "Choose the eBay computer for this signed-in Chrome profile.",
        "Click Scan Active Listings and leave the inactive eBay worker tab available until every 200-row page and the final count are verified.",
        "If eBay live scanning is unavailable, download its current All active listings CSV and choose Import Active Listings CSV.",
        "Confirm the indexed listing count, decoded ASIN count, account label, and Last verified time.",
        "Enter any useful search words, leave Exclude products already active on eBay enabled, and start the Amazon hunt.",
        "Review Excluded rows for exact active SKU/ASIN matches and Review rows for exact normalized-title duplicates, conditional policies, or unreadable evidence.",
        "Copy evidence for Preflight candidates and run it through Listing Policy Check before Bulk Poster."
      ],
      "approvalStop": "The guard never edits eBay and requires no marketplace approval. Any later EcomSniper listing action retains its own explicit approval boundary.",
      "output": "A computer-bound verified Active Listings index, duplicate decisions in the audit CSV, and integrity-checked evidence bundles for eligible Preflight candidates.",
      "recovery": [
        "A partial scan never replaces the prior verified index.",
        "If eBay displays a browser check, complete it in the saved worker tab and click Resume Scan.",
        "If the Active Listings total changes during scanning, stop and rerun after eBay settles.",
        "Protected hunts cannot start without a verified index for the selected computer unless the operator explicitly disables the guard."
      ],
      "evidence": "The complete scanner, CSV import, exact SKU/ASIN exclusion, title-review, computer binding, permission boundary, and fail-closed behavior are deterministic-test proven. A current signed-in Profile 2 full scan remains the live gate."
    },
    {
      "id": "sniping",
      "matrix": "C-03",
      "title": "Sniping Workflow",
      "status": "PENDING USER REVIEW",
      "summary": "Choose close competitors, verify exact products, enforce economics, and stop at a read-only review.",
      "prerequisites": [
        "An exact Amazon product page shows a valid ASIN and price.",
        "The user is prepared to manually confirm product identity and EcomSniper private-page steps."
      ],
      "steps": [
        "Click Start Sniping Workflow from the exact Amazon product.",
        "Review the capped eBay candidate set returned to Amazon.",
        "Open source links and manually confirm title/brand, image, pack, size, color, and variant.",
        "Save one verified seller only when it looks like a matching dropshipper.",
        "Scan that seller in EcomSniper and select a proven recent-selling winner.",
        "Capture the winner on eBay and open the exact Product Hunter match.",
        "Review markup, exact $0.05 undercut, fee, spread, and conservative profit.",
        "Save Read-Only Review only after exact identity confirmation."
      ],
      "approvalStop": "The workflow must stop at read-only review. It cannot create, edit, or submit an eBay listing.",
      "output": "A saved read-only seller/winner/product/economics review with no listing action.",
      "recovery": [
        "Markup alone never proves an Amazon match.",
        "A mismatch or unprofitable result cannot advance.",
        "EcomSniper continuation remains unverified and must stay manual."
      ],
      "evidence": "A recorded Profile 2 candidate and 80.1% markup proof exists, but the user deferred review and EcomSniper continuation remains unverified."
    },
    {
      "id": "poshmark-stats",
      "matrix": "P-01, P-02",
      "title": "Poshmark Stats",
      "status": "LIVE PASS",
      "summary": "Review requested closet statistics and save one snapshot per Chicago day with deltas.",
      "prerequisites": [
        "The signed-in My Posh Stats page is open.",
        "Computer 7, M0, or the combined computer 0 profile is saved correctly."
      ],
      "steps": [
        "Open My Posh Stats.",
        "Click Scan Posh Stats.",
        "Review shipped orders, days to ship, cancellations, returns, removed listings, profile and available listings, ratings, and requested totals.",
        "Click Save Poshmark Stats.",
        "Confirm the dashboard latest row and daily history/deltas."
      ],
      "approvalStop": "Saving reviewed stats needs confirmation but performs no marketplace write.",
      "output": "One latest snapshot and one upserted daily history row for dashboard computer 7.",
      "recovery": [
        "Do not save if the signed-in closet identity is wrong.",
        "Same-day saves update one row instead of adding duplicates.",
        "Legacy same-day duplicates are repaired before deltas rebuild."
      ],
      "evidence": "All requested Profile 2 metrics and dashboard/history readbacks are live-proven."
    },
    {
      "id": "poshmark-profit",
      "matrix": "P-03, P-04, P-05, P-06, P-07",
      "title": "Poshmark Sales and Profit",
      "status": "PARTIAL",
      "summary": "Decode the sale SKU, find the exact Amazon order-item cost, and save deduplicated profit evidence.",
      "prerequisites": [
        "The signed-in Poshmark sale order shows earnings and an EcomSniper SKU.",
        "Signed-in Amazon Orders is available in the same Chrome profile."
      ],
      "steps": [
        "Open the Poshmark sale order and click Capture Order Profit.",
        "If needed, click Open Amazon Orders for ASIN.",
        "Verify the decoded SKU ASIN against an exact Amazon order-details item row.",
        "On Amazon, click Review & Copy Amazon Info.",
        "Return to Poshmark and click Capture Order Profit again.",
        "Review earnings, per-item Amazon cost, profit, margin, SKU, ASIN, and supplier order.",
        "Click Save Profit only when every identity matches.",
        "Use Capture Visible Sales separately for the quick sales list import."
      ],
      "approvalStop": "Saving reviewed profit needs confirmation but performs no marketplace write or purchase.",
      "output": "One upserted Marketplace Profit History row and computer 7 profit row with exact supplier evidence.",
      "recovery": [
        "Never use EcomSniper markup, product-page price, checkout total, or a different order.",
        "A missing, stale, redirected, extra, or mismatched ASIN blocks Save.",
        "Visible Sales import remains partial and must not be treated as full profit proof."
      ],
      "evidence": "Ten exact Profile 2 order-cost/profit matches are live-proven. The separate visible-sales import lacks current-version dashboard readback."
    },
    {
      "id": "poshmark-profit-backfill",
      "matrix": "P-08",
      "title": "Historical Poshmark Profit Backfill",
      "status": "LIVE PASS",
      "summary": "Index paginated Poshmark sales by range or calendar month, read each exact SKU-linked order, allocate exact Amazon purchase units once, and stage a review before any spreadsheet write.",
      "prerequisites": [
        "Use the Chrome profile already signed into both Poshmark and Amazon.",
        "The saved computer must be Poshmark-enabled.",
        "Set the Amazon profile label if supplier-profile reporting is required."
      ],
      "steps": [
        "Open Workflows in the popup, or click Historical Profit Backfill on a Poshmark page, and choose Current sale, Pilot, New since last sync, Last 90 days, One month, or All sales.",
        "For the initial history, use One month and enter YYYY-MM, such as 2026-04 for April 2026. Month-by-month is recommended; All sales is available for a deliberate full-history migration but creates a much larger review and recovery surface.",
        "Start or Resume opens one reusable Profit Run Progress tab. Keep it open to see the current phase, current order or ASIN, exact and unresolved counts, errors, pause reason, and destination tab without interrupting the signed-in worker.",
        "Let the single background worker switch Poshmark to Show 100 and index only the selected range or month.",
        "Let the worker open each Poshmark sale detail and decode every EcomSniper SKU into an exact ASIN.",
        "Let it search all matching Amazon order result pages and open each exact order detail in the same worker tab.",
        "Review every row, including earnings, exact Amazon item cost, supplier order, unresolved reason, and attempted Amazon profile.",
        "Approve the exact month and live row count before creating or updating the month tab; unresolved costs remain blank and enter the shared queue.",
        "After a confirmed, non-queued sync, GLDN Ops opens or focuses the actual Poshmark profit workbook. Use the progress page workbook buttons at any time to inspect existing saved rows; unsynced work never appears there.",
        "On another signed-in Amazon Chrome profile, use Resolve Missing Amazon Costs to retry open queue rows, then approve the exact resolution count.",
        "Repeat each missing historical month once, then use New since last sync for ongoing additions. The dashboard totals the saved monthly tabs without rescanning completed sales."
      ],
      "approvalStop": "STOP at the review. A month write requires APPROVE SYNC POSHMARK YYYY-MM N, and a cross-profile resolution requires APPROVE RESOLVE POSHMARK COSTS N.",
      "output": "A resumable checkpoint, one-use Amazon unit ledger, a formatted month tab, exact profit rows, and a shared unresolved-cost queue that can be completed from another signed-in Amazon profile without duplicate sales.",
      "recovery": [
        "Pause at Safe Checkpoint before closing the worker tab.",
        "If the popup closes, reopen the durable Profit Run Progress page; it reads the saved checkpoint and never starts a duplicate run.",
        "If a worker tab closes, becomes blank, or stops reporting progress, GLDN Ops pauses at the exact checkpoint instead of restarting or writing rows.",
        "A failed signed-in worker tab is preserved for inspection and Resume; deliberate Pause closes only the worker and retains progress.",
        "Missing or ambiguous Amazon costs remain blank rather than becoming zero.",
        "Use Resolve Missing Amazon Costs from another signed-in Amazon profile; every attempted profile is retained.",
        "Never substitute EcomSniper markup, a product-page price, cart total, checkout total, or a different Amazon order."
      ],
      "evidence": "The original exact single-order path is live-proven in Profile 2. v3.11.35 added month filtering, formatted monthly output, unresolved-cost queuing, and cross-profile resolution. v3.11.36 through v3.11.41 hardened empty-page rejection, reload recovery, complete page loading, pagination, Show 100 selection, and review-time detail repair. Dashboard deployment @42 is live. The approved April 2026 run saved 317 unique reviewed orders: 260 exact Amazon costs and 57 unresolved costs retained blank and queued without duplicate sales. v3.11.42 aligns approval with every reviewed row, uses deterministic durable batches, and closes completed worker checkpoints. The approved May 2026 sheet already contains 386 reviewed orders and must not be restarted or duplicated. v3.12.27 adds closed, blank, and silent-worker recovery with a preserved signed-in failure tab and exact Resume checkpoint. v3.12.28 adds a durable live progress page and opens the real workbook only after a confirmed non-queued sync."
    },
    {
      "id": "tasks-automation",
      "matrix": "F-10, T-04, T-05, T-06",
      "title": "Tasks Reminders and Auto-Completion",
      "status": "LIVE PASS",
      "summary": "Keep task order safe, show stale warnings, and check only exact proven workflow completions.",
      "prerequisites": [
        "The shared Tasks sheet retains its task labels and computer headers."
      ],
      "steps": [
        "Run the read-only schema audit after changing task labels or computer headers.",
        "Require every header and target label to match exactly once before a Tasks write.",
        "Review daily stale warnings after more than three days.",
        "Review NEED TO SNIPE after more than five days since the latest computer timestamp.",
        "Review the Subscribe & Save reminder beginning one day before month end.",
        "Allow only seller metrics, listing limits, Mark as Shipped, and exact zero-remaining Move .99 proof to auto-check directly.",
        "Keep one Amazon Subscribe & Save proof per cleared Chrome profile; a single profile cannot check the ALL Amazon Accounts row.",
        "Require explicit all-profile proof and the exact token APPROVE ALL AMAZON PROFILES N before that monthly row can be checked.",
        "Keep the second-round row manual."
      ],
      "approvalStop": "No Tasks checkbox may stand in for marketplace approval. Review-ready or partial states cannot auto-check completion.",
      "output": "Label-based warnings and idempotent, computer-specific checkbox updates.",
      "recovery": [
        "A missing or duplicate task label/header must stop the write until the schema is corrected.",
        "Row moves are safe only because integrations locate unique task labels.",
        "Poshmark-only cells remain grey.",
        "Reverse cleanup, EcomSniper handoffs, sniping, and second-round tasks never auto-check."
      ],
      "evidence": "Production schema audit, threshold, stale reminder, layout, allowlist, temporary-sheet cleanup, and exact computer-column proofs are live-passed. F-10 proof: https://drive.google.com/file/d/1LL8bus-SnrpPITUglPoX6K2uFi8Bz4uB/view?usp=drivesdk"
    },
    {
      "id": "diagnostics",
      "matrix": "F-11, F-12, U-02",
      "title": "Diagnostics, Backup, and Interface Settings",
      "status": "PARTIAL",
      "summary": "Capture failures before resetting and preserve per-profile settings across updates.",
      "prerequisites": [
        "The popup can open."
      ],
      "steps": [
        "Use Settings to choose theme and transparency.",
        "Click Copy Settings Backup before updates or profile moves.",
        "Use Status to run Feature Health Check.",
        "After a failure, click Copy Full Diagnostic Report before Reset.",
        "Use Copy Error Log for a shorter page-error report.",
        "Clear Error Log only after the issue is captured.",
        "Restore settings from the copied backup and verify identity and categories."
      ],
      "approvalStop": "Diagnostics and settings must not trigger marketplace actions.",
      "output": "Health report, error log, diagnostic report, and restorable settings backup.",
      "recovery": [
        "Do not clear evidence before copying it.",
        "F-11 controlled error storage and export are live-proven in Profile 2.",
        "U-02 installed-popup tab persistence still needs manual confirmation."
      ],
      "evidence": "Health diagnostics and the exact controlled error-log storage/export path are live-proven in Profile 2. Popup behavior and visuals are contract-proven; U-02 installed-popup tab persistence remains pending."
    },
    {
      "id": "onboarding-interface",
      "matrix": "U-01, U-02, U-03",
      "title": "Feature Tour, Themes, and Universal Access",
      "status": "PARTIAL",
      "summary": "Teach every catalog feature, keep the panel readable, and expose safe global controls on ordinary webpages.",
      "prerequisites": [
        "GLDN Ops is loaded in the intended Chrome profile.",
        "The page is an ordinary http or https webpage; Chrome internal pages cannot run extension content scripts."
      ],
      "steps": [
        "On first installation, use Next and Previous to review every feature, or click Skip for now.",
        "Restart the tour from Start Feature Tour in the popup or the three-dot panel settings menu.",
        "Open the full feature guide for exact recovery steps and evidence labels.",
        "Choose a saved theme from Core, Limited Editions, or Retired Editions in Settings.",
        "Use the three-swatch preview to confirm the selected window, surface, and accent palette.",
        "Use each review window's 0%-100% transparency slider to reveal the webpage behind its shell, tables, fields, and controls.",
        "Drag a review window by its title; double-click the title to reset its saved position.",
        "Resize a review window from its lower-right corner and resize the floating panel from its handle.",
        "Minimize or dock the panel to the right edge when it obstructs a webpage.",
        "On unsupported sites, use only the safe global controls; marketplace actions appear only on their supported sites."
      ],
      "approvalStop": "Theme, layout, tour, guide, dashboard, diagnostics, and stop controls perform no marketplace write. Marketplace approval boundaries remain unchanged.",
      "output": "A skippable feature-by-feature tour, complete guide, 49 persisted themes, independently transparent, draggable and resizable review windows, seamless scrollbars, and a safe panel on ordinary webpages.",
      "recovery": [
        "Use Reset panel layout if a saved panel size or position is awkward.",
        "Reopen the tour from the popup after skipping it.",
        "Chrome pages such as chrome://extensions cannot display the webpage panel; use the toolbar popup there.",
        "If a supported marketplace shows only global controls, reload that tab once after reloading the extension."
      ],
      "evidence": "v3.8.2 proved all 49 theme options in signed-in Profile 2. v3.8.3 proved independent Poshmark and eBay review-window opacity, translucent inner surfaces, dragging, and saved position. v3.8.4 proved Poshmark Stats at true 0%: modal shell, inner table, theme pattern, and page backdrop all reached zero alpha while the everyday panel remained at 65%; 0% persisted after reopen; live money rows displayed $33,642.00 and $94,165.15; large counts used separators; and a clean repeat produced no new warnings or errors. The review was restored to 65% and closed without Save, with zero marketplace actions. Evidence: evidence/profile2-modal-opacity-currency-v384-2026-07-23/."
    },
    {
      "id": "walmart",
      "matrix": "U-04",
      "title": "Walmart Order Helper",
      "status": "IMPLEMENTED, UNPROVEN",
      "summary": "Carry encoded order details into Walmart cart/checkout while preserving a manual final purchase.",
      "prerequisites": [
        "A Walmart link contains the intended auto-order details from a reviewed eBay handoff."
      ],
      "steps": [
        "Open the encoded Walmart product link.",
        "Confirm GLDN Ops removes customer data from the address bar after storing it locally.",
        "Review the product and quantity.",
        "Use Add / Checkout only on safe cart controls.",
        "Use Fill Delivery Info at checkout.",
        "Review customer, item, shipping, total, and payment values manually."
      ],
      "approvalStop": "GLDN Ops must never click Place order or another final purchase control.",
      "output": "A prepared Walmart checkout with no purchase submitted.",
      "recovery": [
        "Stop if the item, quantity, address, price, shipping, or payment differs.",
        "This feature has syntax and package coverage only and must be treated as unproven until a dedicated gate."
      ],
      "evidence": "Implemented and packaged, but no current signed-in live proof exists."
    }
  ]
});
