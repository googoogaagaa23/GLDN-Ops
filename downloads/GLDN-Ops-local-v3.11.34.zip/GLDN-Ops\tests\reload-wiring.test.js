const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");

test("in-extension reload survives the old content-script context", () => {
  const root = path.resolve(__dirname, "..");
  const background = fs.readFileSync(path.join(root, "extension", "background.js"), "utf8");
  const poshmark = fs.readFileSync(path.join(root, "extension", "poshmark.js"), "utf8");
  const amazon = fs.readFileSync(path.join(root, "extension", "amazon.js"), "utf8");
  const ebay = fs.readFileSync(path.join(root, "extension", "ebay.js"), "utf8");
  const popupHtml = fs.readFileSync(path.join(root, "extension", "popup.html"), "utf8");
  const popupJs = fs.readFileSync(path.join(root, "extension", "popup.js"), "utf8");
  const reloadJs = fs.readFileSync(path.join(root, "extension", "reload.js"), "utf8");
  const startMove99Js = fs.readFileSync(path.join(root, "extension", "start-move99.js"), "utf8");
  const snipingReviewJs = fs.readFileSync(path.join(root, "extension", "sniping-review.js"), "utf8");

  assert.match(background, /pending:\s*true/);
  assert.match(background, /resumeExtensionReloadRequest/);
  assert.match(background, /chrome\.tabs\.query/);
  assert.match(background, /chrome\.tabs\.reload/);
  assert.doesNotMatch(poshmark, /setTimeout\(\(\) => location\.reload\(\), 2500\)/);
  assert.doesNotMatch(amazon, /setTimeout\(\(\) => location\.reload\(\), 2500\)/);
  assert.doesNotMatch(ebay, /setTimeout\(\(\) => location\.reload\(\), 2500\)/);
  assert.match(popupHtml, /id="updateExtension"[^>]*>Update &amp; Reload<\/button>/);
  assert.match(popupHtml, /id="reloadExtension"[^>]*>Reload Current Files<\/button>/);
  assert.match(popupJs, /getElementById\('reloadExtension'\)\.addEventListener\('click'/);
  assert.match(popupJs, /getElementById\('updateExtension'\)\.addEventListener\('click'/);
  assert.match(popupJs, /type:\s*'reloadExtension'/);
  assert.match(popupJs, /type:\s*'updateExtension'/);
  assert.match(reloadJs, /trustedMove99Recovery/);
  assert.match(reloadJs, /pending\?\.phase === 'awaiting-submit-approval'/);
  assert.match(reloadJs, /pending\?\.trustedSubmitDispatchAt/);
  assert.match(reloadJs, /pending\?\.trustedSubmitReleasedAt/);
  assert.match(reloadJs, /trustedSubmitRecoveryActivationCount/);
  assert.match(reloadJs, /exactTabs\.length !== 1/);
  assert.match(reloadJs, /chrome\.runtime\.reload\(\)/);
  for (const source of [reloadJs, startMove99Js, snipingReviewJs]) {
    assert.match(source, /Extension request timed out/);
    assert.match(source, /chrome\.runtime\.lastError/);
  }
});
