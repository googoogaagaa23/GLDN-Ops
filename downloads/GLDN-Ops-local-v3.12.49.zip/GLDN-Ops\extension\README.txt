GLDN Ops v3.12.49

v3.12.49 unread customer messages:
- Open the GLDN icon > Daily > Unread Customer Messages, or use the eBay panel button.
- Scan Unread Messages reads the native Unread from members folder without opening conversations.
- All matching rows are shown. Ignore removes a conversation from the GLDN pending count; Restore reverses it.
- Open All Pending opens every unignored unread conversation in a separate eBay tab. eBay can mark opened messages read.
- Ignore preferences are local to the Chrome profile and eBay account; a changed preview returns to pending.
- Pause/Resume retain completed reads. No reply, delete or archive is performed.
- A saved count is a snapshot: scan again for current unread status.

v3.12.48 relative Amazon dates and eBay note menu:
- Arriving Tomorrow automatically becomes the next local calendar date.
- Today, time windows, month/year rollover and daylight-saving changes are handled.
- Fill eBay note recognizes Add order note and Edit order note as well as Add/Edit note.
- An already-open menu is reused. The final eBay Save remains manual.
- Update & Reload, then refresh Amazon and eBay tabs before retrying.

v3.12.47 included dashboard and optional extension setup:
- New profiles automatically load the owner-approved shared dashboard connection.
- Existing saved connections and local overrides stay intact through updates.
- Test Connection verifies server access; configured does not mean synced.
- Open the GLDN icon > Optional Extension Setup for eComSniper and Trackerbot.
- Fresh installs open these optional choices; normal updates do not.
- eComSniper downloads use versioned folders after optional download permission.
- Trackerbot opens its official store and sign-in; approve Add to Chrome yourself.
- Provider passwords are not bundled. The shared dashboard key is public by request.

v3.12.46 Amazon ETA and visible eBay note draft:
- Amazon's "Arriving by Oct 7, 2026" now fills ETA as 10/7.
- Late-arriving delivery dates fill the open review without replacing manual edits.
- eBay Order Details has a GLDN Order Note box even with the side panel collapsed.
- Use copied Amazon info or enter a note, review the order, then Fill eBay note.
- eBay Save stays manual. Checkout drafts do not confirm purchases or sync profit.
- Update & Reload on each profile, then refresh the Amazon and eBay tabs.

v3.12.45 optional dashboard for listing checks:
- Existing Listings and Listing Policy Check no longer need a dashboard setup code.
- Built-in rules plus locally saved and cached shared incidents still apply.
- Missing, offline or slow shared history shows a warning without stopping the check.
- Newer incidents from other profiles may be missing until shared history reconnects.
- Explicit Sync Shared History still requires a working dashboard and verified readback.
- Update & Reload, then reopen the listing check. Bulk End approval is unchanged.

v3.12.44 dashboard connection repair:
- Connect Dashboard now opens a masked, pasteable field inside the popup.
- Paste the existing private code, then choose Save & Test.
- Cancel leaves saved settings untouched. Connection failures remain visible.
- No marketplace actions or changes to policy scan concurrency.

v3.12.43 stronger pesticide prevention:
- Blocks botanical plant sprays, rooting treatments, septic/pool chemicals, repellents and disinfecting products.
- Handles pesticide plurals, hyphens, common spelling variants and microbial kill claims.
- Uses the same rules in Listing Policy Check, existing-listing audits and Product Hunter v0.3.4.
- After Update & Reload, reopen Listing Policy Check and check pasted links again.
- For a saved Existing Listings Policy Audit, click Refresh Policy Checks; use Start Fresh Complete Scan for new listings.
- No automatic listing changes. Review selected flagged items and approve the exact End batch.

v3.12.42 removed listing history:
- Open Removed Listing History in the popup, then Scan This eBay Account.
- Reads Inactive > View Listings and available case explanations without changing listings.
- Shares exact product incidents through the existing authenticated dashboard, not public GitHub.
- Repeat on each eBay profile; updated profiles use the combined history during policy checks.
- Exact ASINs block, closely matching titles need review, and unrelated brands/categories remain separate.
- Use Refresh Policy Checks on a saved Existing Listings audit after sharing new history.

v3.12.41 all policy audit rows:
- Rows per page defaults to All, displaying every matching result in one scrollable list.
- Optional 100, 250 and 500 row pages remain available. Changing display size keeps selections.
- This is a display change only; exact End batches remain limited to 200 approved listings.
- Reopen the updated audit to use saved results without rescanning.

v3.12.40 combined policy flags:
- Block + Review is the default results view, with both classifications visible together.
- Select All Block + Review selects both categories across every page, excluding ended or unconfirmed items.
- Mixed batches use the existing exact eBay review and approval flow, up to 200 listings per batch.
- Individual Block, Review, All, No rule match and Ended views remain available.

v3.12.39 native ending result recovery:
- Check eBay Result is available even when items were ended directly on eBay.
- Exact per-item ended evidence is saved; hidden policy-violation rows are not treated as ended.
- Set Aside Batch & Continue preserves unresolved IDs and allows other Review flags to proceed.
- Saved batches can be checked later without another End submission. Updates preserve old batch evidence, not old approval.
- Existing calibrated policy rules and pesticide/aerosol exclusions are unchanged.

v3.12.38 policy batches and calibrated screening:
- Restores bulk selection, exact-item native eBay review and one-use approval, up to 200 listings.
- Uncertain submissions are not retried; Check eBay Result reads the result or Ended Listings.
- Refresh Policy Checks reuses saved rows without changing their original scan date.
- Ordinary brands, compatibility, OEM, warranty and generic inspiration are not blanket holds.
- Pesticides, spray cans and explicit counterfeit signals remain blocked.
- No live listing was ended during development. Live ending validation remains pending.

v3.12.37 IP screening and changing-store scans:
- Adds targeted counterfeit, unauthorized-copy, character/logo licensing and authenticity checks to both preflight and existing-listing audits. Ordinary brand names alone remain allowed by the keyword check.
- Existing-listing policy scans finish a bounded pass when daily listing totals change, deduplicate repeated item IDs, and show a follow-up coverage warning instead of discarding the audit.
- Incomplete pages, browser checks, wrong-account checkpoints and marketplace approval boundaries remain protected.
- Resume can apply current rules to saved raw pages without rereading completed pages.
- Pesticides and spray cans remain blocked. No-match text is not proof of authenticity or eBay permission.


v3.12.36 shipment completion recovery:
- A delayed eBay success banner releases the completed Mark as Shipped workflow.
- Seller Level and snapshot starts reconcile exact completion first.
- Recovery never clicks Mark as shipped again; another tab or an empty table alone cannot complete a run.
- A late click acknowledgment cannot restore a cleared or replaced shipment run.

v3.12.35 dashboard confirmations and Tasks timestamps:
- Checks Google's exact saved receipt after a lost sync response.
- Unconfirmed saves are pending confirmation, not a claim that nothing was saved.
- Live Tasks automation stamps manual values and every cell in pasted blocks.
- Late Shipment Rate targets the metric row, not the parent checkbox.
- Historical timestamps are preserved; no old edits are assigned invented dates.

v3.12.34 Mark as Shipped approval recovery:
- Nested menu rows and buttons count as one eBay action; separate matches still stop.
- Rechecks the selection and Shipping menu immediately before activation.
- Failed approval no longer locks the page. Close review stays available after failure.
- A confirmed no-click failure allows a fresh approval. An uncertain click requires reviewing eBay first and is never retried automatically.
- GLDN's own approval window is never used as eBay confirmation evidence.
- Keeps all v3.12.33 policy-audit recovery changes.

v3.12.33 existing-listings policy audit recovery:
- Shows classification progress after all listing pages have been collected.
- Resume finishes saved final-page scans without opening a nonexistent extra page.
- Interrupted scans and their saved listing pages survive the repair update.
- Reopen Existing Listings Policy Audit and choose Resume Scan after updating.
- Do not use Reset or Discard Local Audit to clear an old update blocker; use the current installer in the same loaded folder, then reload the extension in Chrome.
- Read-only repair: no listings are ended and policy decisions are unchanged.

v3.12.31 reverse category launch repair:
- Sale Event Is OFF starts the read-only Non-.99 scan without the prompt blocking its own workflow.
- Repeated start clicks do not replace the open sale-event question.
- Sale Event Is ON and real approval reviews still stop the launch. Listing changes remain approval-gated.

Current operator rule: the v3.12.30 paste-first keyword workflow below supersedes older historical entries about a 500-word allowlist, generic-brand gate, or five attestations. Do not follow those older instructions.

v3.12.30 paste-first listing policy check:
- Accepts any Product Hunter search words and does not stop products merely because they have a brand, manufacturer, model, or unfamiliar wording.
- Opens Listing Policy Check directly with no clipboard prerequisite and removes the 500-word grid and official/Discord/Telegram source cards from the operator page.
- Accepts pasted product titles or Amazon links; raw links are read sequentially in one inactive Amazon tab and cached for safe resume.
- Copies only readable no-match Ready links. Conditional policy matches and unreadable products stay in Needs review; prohibited-item matches are Blocked.
- Adds explicit GLDN Blocks for every pesticide product and every spray can, including registered pesticides and aerosol or pressurized cans.
- Keeps Existing Listings Policy Audit read-only while applying the same keyword rules to active listing titles.
- No keyword no-match or Ready result is an eBay guarantee or approval, and no check changes a listing.
- Load and pin the unpacked extensions manually on each computer/profile. Installation does not restore selling permission and must never be used with another computer, profile, or account to evade an eBay restriction.

v3.12.29 eBay policy and IP safety refresh:
- Reviews the complete official eBay prohibited-and-restricted hub and every linked policy page, plus the linked intellectual-property and VeRO guidance.
- Expands the shared source-linked pack to 578 rules: 576 official eBay rules and 2 Discord community Review warnings; Telegram still contributes zero item rules.
- Publishes exactly 500 versioned generic Product Hunter starting phrases and rejects unknown seeds in the standalone Product Hunter before any Amazon worker tab opens.
- Ships the standalone GLDN Product Hunter v0.3.0 fail-closed seed, brand/IP, and active-listing guard.
- Keeps every unknown, branded, model-specific, compatibility, licensing, character, franchise, fan-art, or incomplete product in Needs review.
- Lets only explicit current official-policy matches create Block; community evidence can create Review only.
- Makes Existing Listings Policy Audit read-only and keeps every unmatched title/SKU-only listing in Needs review because authenticity, authorization, images, safety, and provenance are not proven.
- Ready is never eBay approval, and no policy scan, Preflight check, or Product Hunter result changes or submits a marketplace listing.

v3.12.28 live profit progress:
- Opens one reusable Profit Run Progress tab whenever Historical Poshmark Profit starts or resumes.
- Shows the live phase, current order or ASIN, counts, exact profit staged, errors, pause reason, and exact sheet destination.
- Keeps progress visible after the popup closes without creating a second worker or changing marketplace data.
- Opens the correct real workbook only after an approved sync succeeds without entering the retry queue.
- Adds direct progress and workbook controls in the popup and Poshmark workflow launcher.

v3.12.27 Poshmark backfill recovery:
- Detects a closed or silent historical-profit worker instead of leaving the run stuck on a blank page.
- Pauses at the exact saved checkpoint and preserves the signed-in failed tab for inspection and Resume.
- Reports Poshmark and Amazon parser/navigation failures to the background controller.
- Keeps deliberate Pause behavior separate: Pause still closes the worker cleanly while retaining progress.
- Does not resync an already approved month or duplicate rows during recovery.

v3.12.26 Product Research Desk:
- Adds selectable lower-risk Product Hunter starting words inside Listing Preflight.
- Shows official eBay, Profile 2 Discord, and Profile 2 Telegram research coverage separately.
- Publishes 175 official rules and 2 Discord-backed Review signals; the reviewed Telegram post correctly publishes no product rule.
- Copies selected words directly into the EcomSniper Product Hunter handoff.
- Keeps Product Hunter results in the existing Ready, Review, and Block link preflight before Bulk Poster.
- Allows community research to create Review warnings only; hard Blocks still require official eBay evidence.

v3.12.25 in-extension workflow guides:
- Adds a searchable Guides tab with all 29 canonical workflow and setup guides.
- Adds a compact ? guide control beside every main workflow launcher.
- Opens contextual guide links directly to the requested workflow with its steps expanded.
- Adds a collapsible full guide inside eBay Profit Audit, Order Placement Audit, Existing Listings Policy Audit, Variation Listings, Listing Preflight, Sniping Review, and both Move .99 launch paths.
- Keeps prerequisites, exact steps, approval stops, expected results, and recovery instructions generated from one versioned catalog.

v3.12.24 Order Placement Audit access:
- Adds an always-visible Open Order Placement Audit shortcut near the top of the full extension popup.
- Keeps the existing Workflows > Profit entry.
- Opens the same read-only cross-profile audit from every participating Amazon Chrome profile.
- Renames Monthly eBay Profit to eBay Profit Audit.
- Adds one-month or all-available-history reads.
- Shows Pending instead of $0.00 when no saved-note profit has been confirmed.
- Shows saved-note profit coverage and labels partial totals clearly.
- Names the two methods Saved-note profit and Independent Amazon profit.

v3.12.23 updater-ready order audit release:
- Publishes the cross-profile Order Placement Audit through Update & Reload.
- Keeps the permanent Amazon profile label and completed profile scan visible after extension reloads.
- Preserves the shared July eBay demand and profile-by-profile Amazon progress without marketplace writes.
- Keeps incomplete profile coverage clearly marked partial until every expected Amazon profile is scanned.

v3.12.22 cross-profile order-placement audit:
- Builds exact monthly eBay unit demand from a completed Monthly eBay Profit run.
- Scans exact-ASIN Amazon order details separately in every signed-in Amazon Chrome profile.
- Combines those profile results through the shared dashboard without counting one Amazon order twice.
- Flags likely same-recipient duplicates, possible different-recipient extras, canceled-order purchases, and missing purchases.
- Remains read-only and never cancels, refunds, purchases, marks shipped, or edits an order.
- Profile 2 control can seed, start, resume, and read the audit without manual extension-page operation.

v3.12.21 monthly-profit visible-review release:
- Keeps the final signed-in eBay worker page open when Monthly eBay Profit reaches review.
- Closes that worker only after the reviewed month is fully synced or explicitly reset.
- Prevents stale zero-result text in eBay's SPA from overriding visible order-detail links.
- Shows a clear zero-order review message instead of silently removing the worker page.

v3.12.20 monthly-profit launch repair:
- Stops Monthly eBay Profit from deleting its own worker tab when eBay page verification fails.
- Leaves the exact failed eBay tab open and shows the real failure reason.
- Reuses that preserved signed-in tab when Resume is clicked.
- Recognizes eBay's encoded All Orders URL on layouts that do not expose selected navigation metadata.
- Finds nested All Orders and Period controls used by alternate eBay Orders layouts.
- Keeps deliberate Pause, Reset, review, and completion cleanup unchanged.

v3.12.19 monthly-profit worker recovery release:
- Detects when Chrome or eBay closes the monthly-profit worker before completion.
- Immediately changes the run from Running to a resumable Paused checkpoint.
- Shows the closure reason on the Monthly eBay Profit page instead of leaving stale progress.
- Rechecks worker existence whenever status is read or a new run is requested.
- Keeps normal review/completion closure unchanged.

v3.12.18 dual-source eBay profit release:
- Makes Read 1 a true saved-note-only calculation: note earnings minus note Amazon cost.
- Keeps Read 2 independent: visible eBay order earnings minus an exact matched Amazon order-item cost.
- Shows both results side by side without allowing one source to overwrite the other.
- Automatically normalizes deterministic money formatting mistakes in saved notes.
- Requires an editable operator confirmation when a note amount is ambiguous, inconsistent, or likely missing a decimal.
- Never changes an eBay order or note when confirming internal profit amounts.

v3.12.17 Amazon-cost resolution save release:
- Makes Save Cost Resolution Results a single explicit action instead of a hidden two-click confirmation.
- Keeps the review window visible while two durable 50-row dashboard batches finish.
- Shows a persistent saved or safely queued receipt with exact and still-open counts.
- Clarifies that the Monthly eBay Profit run remains in the eBay Chrome profile while Amazon profiles save only reconciliation receipts.
- Leaves unresolved rows open for another signed-in Amazon profile and never guesses a missing cost.

v3.12.16 Prepare Order Note recovery release:
- Saves reviewed Amazon order evidence inside GLDN Ops before attempting the optional clipboard copy.
- Lets Prepare Order Note recover the exact saved handoff when clipboard access is unavailable.
- Opens a visible recovery window for missing, stale, wrong-order, or mismatched evidence instead of appearing to do nothing.
- Still stops before eBay Save and never syncs a new note before eBay visibly saves it.

v3.12.15 policy-audit control release:
- Adds a Profile 2-only command that cancels an abandoned policy review and runs the complete read-only Active Listings scan.
- Returns exact total, no-match, review, and Block counts without exposing any listing End action.

v3.12.14 policy-audit recovery release:
- Treats eBay messages such as "Listing item is missing" as unresolved failures, never as successful listing Ends.
- Adds Cancel Review & Rescan so an abandoned or stale native eBay review cannot lock the store audit.
- Starts a new complete read-only Active Listings scan after recovery without changing any listing.

v3.12.13 policy-audit operations release:
- Exposes the complete saved Existing Listings Policy Audit state through the read-only Profile 2 control channel.
- Allows the local controller to open the detailed policy-audit page without browser URL workarounds.
- Keeps review and End evidence separate; no listing can be changed through state readback.

v3.12.12 existing-listings policy audit release:
- Scans every eBay Active Listings page read-only and verifies every reported row and unique item number before publishing an audit.
- Saves verified 200-row checkpoints so an interrupted or paused scan can resume without pretending it is complete.
- Applies the same 175 source-linked reviewed policy rules used by Listing Preflight.
- Separates No rule match, Needs review, and reviewed Block results. Needs review rows can never be selected for ending.
- Opens a visible native eBay review for only the exact selected Block item numbers, in batches of at most 200.
- Requires the exact action-time phrase APPROVE END POLICY LISTINGS N before the irreversible eBay End request.
- Rechecks the current computer/account, audit age, rule-pack fingerprint, exact Block status, completed ledger, and eBay eligibility immediately before ending.
- Stops after every approved batch. It never starts or submits a later batch automatically.
- Adds CSV audit export, completion receipts, pause/resume, and local-audit recovery controls.

v3.12.6 workflow organization and Product Hunter companion release:
- Groups advanced controls into Daily, Listings, Research, Profit, Supplier, and Poshmark lanes while keeping Status and Settings separate.
- Remembers the last selected workflow lane in each Chrome profile.
- Hides Poshmark-only controls on eBay-only computers and disables eBay-only controls on the Poshmark-only computer.
- Makes Prepare Order Note fail clearly unless an eBay order-details page is open.
- Keeps the everyday floating panel focused on daily actions; monthly profit, dashboard setup, and health diagnostics remain in its three-dot settings menu.
- Ships the separate GLDN Product Hunter v0.2.0 package with a complete read-only eBay Active Listings guard.
- Product Hunter excludes exact active SKU/ASIN matches and sends exact normalized-title matches to manual review before a link can become Ready.
- Requires a verified complete Active Listings scan or imported current CSV for the selected eBay computer before duplicate protection can be claimed.

Preserved v3.12.5 reconciliation and listing-preflight behavior:
- Requires one permanent Amazon profile name before an eBay or Poshmark missing-cost run begins.
- Displays and records the exact supplier profile plus the live pending review count.
- Skips unresolved rows already attempted by that permanent profile and leaves misses open for another signed-in Amazon profile.
- Keeps exact count-bound approval before any reviewed cost results sync to the shared dashboard.
- Preserves saved-note profit separately from independent Amazon-order profit for discrepancy review.
- Publishes 175 source-linked, human-reviewed rules derived from official eBay listing policies.
- Adds a Ready-only Product Hunter-to-Bulk Poster handoff using canonical Amazon links.
- Keeps Needs review, Blocked, duplicate, opaque, and non-Amazon inputs out of the Bulk Poster clipboard.
- Fails closed when reviewed rules are empty or unavailable.
- Does not use an eBay API, submit a listing, start Bulk Poster, or claim that a Ready result is eBay approval.
- Delivers large approved profit batches with a bounded 90-second dashboard wait so a slow Apps Script response does not strand an already-accepted batch.
- Live Profile 2 proof separated Ready, Review, and Block samples, copied only one canonical Ready Amazon URL, and opened the exact EcomSniper Bulk Poster page without starting it.
- Live Profile 2 proof opened the exact EcomSniper Scanner and Product Hunter pages, reported only observable tab lifecycle, and stopped only the GLDN-opened tab.
- The approved 29-row F9132 cost review is durably synced; zero rows remain open for that Amazon profile and the dashboard retry queue is empty.
- Other signed-in Amazon profiles remain separate reconciliation gates.
