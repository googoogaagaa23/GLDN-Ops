param([string]$Version = "")

$ErrorActionPreference = "Stop"

$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$extensionRoot = Join-Path $repoRoot "extension"
$manifest = Get-Content -Raw -LiteralPath (Join-Path $extensionRoot "manifest.json") | ConvertFrom-Json
if (-not $Version) { $Version = [string]$manifest.version }
if ($Version -ne [string]$manifest.version) { throw "Requested version $Version does not match manifest version $($manifest.version)." }

$distRoot = Join-Path $repoRoot "dist"
$buildRoot = Join-Path $repoRoot ".local-build"
$stageRoot = Join-Path $buildRoot "GLDN-Ops"
$stageRoot = [IO.Path]::GetFullPath($stageRoot)
if (-not $stageRoot.StartsWith($repoRoot.TrimEnd('\') + '\.local-build\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid local package staging directory.' }
$zipPath = Join-Path $distRoot "GLDN-Ops-local-v$Version.zip"
$latestPath = Join-Path $distRoot "GLDN-Ops-latest.zip"

$extensionFiles = @(
  'deployment-channel.js', 'ops-health.html', 'ops-health.css', 'ops-health.js', 'ops-health-core.js', 'ops-health-background.js',
  'workflow-guide-data.js', 'workflow-guide.css', 'workflow-guide.js',
  "manifest.json", "config.example.js", "dashboard-default.json", "theme-catalog.js", "foundation.js", "shared.js", "control-heartbeat.js", "profit-audit.js", "profit-backfill.js", "profit-backfill-background.js", "sniping-audit.js", "subscribe-save.js",
  "companion-setup-core.js", "companion-setup-background.js", "companion-setup-page.js", "companion-setup.html", "companion-setup.js", "companion-setup.css",
  "sniping-review.html", "sniping-review.css", "sniping-review.js", "background.js",
  "listing-preflight.html", "listing-preflight.css", "listing-preflight-core.js", "listing-preflight.js", "listing-preflight-rules.json", "product-research-output.json",
  "policy-listing-audit.html", "policy-listing-audit.css", "policy-listing-audit-core.js", "policy-listing-audit.js",
  "violation-history.html", "violation-history.css", "violation-history.js", "violation-history-core.js", "violation-history-reader.js", "violation-history-background.js",
  "order-audit.html", "order-audit.css", "order-audit-core.js", "order-audit-background.js", "order-audit.js",
  "profit-progress.html", "profit-progress.css", "profit-progress.js",
  "popup.html", "popup.js", "styles.css", "themes.css", "theme-page.js", "guide.html", "onboarding.html", "onboarding.js", "universal.js",
  "variation-core.js", "variation-audit.html", "variation-audit.css", "variation-audit.js",
  "ebay-profit-core.js", "ebay-profit-background.js", "ebay-profit.html", "ebay-profit.css", "ebay-profit.js",
  "amazon.js", "walmart.js",
  "ebay.js", "ecomsniper.js", "poshmark.js", "reload.html", "reload.js",
  "start-move99.html", "start-move99.js", "README.txt"
)
$projectDirectories = @("tools", "docs", "dashboard", "apps-script-live", "apps-script-live-2", "apps-script-live-3", "releases", "tests", "installer")
$projectFiles = @(
  "CHANGELOG.md", "INSTALL.md", "package.json", "pnpm-lock.yaml",
  "bootstrap-install.ps1", "install-latest.ps1",
  "Install-GLDN-Ops.cmd", "Install-GLDN-Ops-Updater.cmd", "Update-GLDN-Ops.cmd", "Diagnose-GLDN-Ops.cmd", "Start-GLDN-Helper.cmd"
)

New-Item -ItemType Directory -Force -Path $distRoot, $buildRoot | Out-Null
if (Test-Path -LiteralPath $stageRoot) { Remove-Item -LiteralPath $stageRoot -Recurse -Force }
New-Item -ItemType Directory -Force -Path (Join-Path $stageRoot "extension") | Out-Null

foreach ($file in $extensionFiles) {
  $source = Join-Path $extensionRoot $file
  if (-not (Test-Path -LiteralPath $source)) { throw "Missing extension runtime file: $file" }
  Copy-Item -LiteralPath $source -Destination (Join-Path $stageRoot "extension\$file") -Force
}
Copy-Item -LiteralPath (Join-Path $extensionRoot "icons") -Destination (Join-Path $stageRoot "extension\icons") -Recurse -Force
foreach ($runtime in (Get-ChildItem -LiteralPath $extensionRoot -File | Where-Object { $_.Extension -in @('.js','.json','.html','.css','.txt') -and $_.Name -ne 'config.js' })) {
  if (-not (Test-Path -LiteralPath (Join-Path $stageRoot "extension\$($runtime.Name)"))) { throw "Public runtime omitted from local package: $($runtime.Name)" }
}

foreach ($directory in $projectDirectories) {
  $source = Join-Path $repoRoot $directory
  if (-not (Test-Path -LiteralPath $source)) { throw "Missing local release directory: $directory" }
  Copy-Item -LiteralPath $source -Destination (Join-Path $stageRoot $directory) -Recurse -Force
}
foreach ($legacyTool in @("build-webstore-zip.ps1", "local-click-helper.ps1", "test-extension-health.ps1", "test-poshmark-computer-guard.ps1")) {
  $legacyPath = Join-Path $stageRoot "tools\$legacyTool"
  if (Test-Path -LiteralPath $legacyPath) { Remove-Item -LiteralPath $legacyPath -Force }
}
foreach ($file in $projectFiles) {
  $source = Join-Path $repoRoot $file
  if (-not (Test-Path -LiteralPath $source)) { throw "Missing local release file: $file" }
  Copy-Item -LiteralPath $source -Destination (Join-Path $stageRoot $file) -Force
}

$configText = Get-Content -Raw -LiteralPath (Join-Path $stageRoot "extension\config.example.js")
if ($configText -match 'dashboardKey:\s*"[^"]{1,}"') { throw "Local package contains a built-in dashboard setup code." }
$privateKeyPattern = 'GLDN' + '.Private' + '.Seller' + '.Level' + '.[0-9]'
if ($configText -match $privateKeyPattern) { throw "Local package contains a private dashboard setup code." }

foreach ($target in @($zipPath, $latestPath)) {
  if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Force }
}
Compress-Archive -Path $stageRoot -DestinationPath $zipPath -CompressionLevel Optimal
Copy-Item -LiteralPath $zipPath -Destination $latestPath -Force

Write-Host "Built local GLDN Ops release bundle:"
Write-Host "  $zipPath"
Write-Host "  $latestPath"
