const POSH_TRACKER = {
  accounts: [
    {
      accountName: "7",
      inputCell: "F5",
      lastUpdatedCell: "G5"
    },
    {
      accountName: "m0",
      inputCell: "F6",
      lastUpdatedCell: "G6"
    }
  ],

  linkCounterLabelCell: "E2",
  linkCounterCell: "F2",

  historyHeaderRow: 8,
  historyFirstDataRow: 9,
  historyStartColumn: 5, // Column E
  historyColumns: 6,

  protectionDescription: "Protected Posh Listing History"
};


/**
 * RUN THIS FUNCTION ONE TIME AFTER PASTING THE SCRIPT.
 *
 * WARNING:
 * This clears the old tracker and old history in columns E:J.
 */
function setupPoshListingTracker() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = spreadsheet.getActiveSheet();

  ensureSheetSize_(sheet);
  saveTrackerSheetId_(sheet);
  removeOldProtection_(sheet);
  clearOldTracker_(sheet);
  createTopTracker_(sheet);
  createJumpLinks_(spreadsheet, sheet);
  createHistoryTable_(sheet);
  protectHistory_(sheet);
  createEditTrigger_();

  spreadsheet.toast(
    "Tracker restarted successfully. Old history was cleared.",
    "Setup Complete",
    6
  );
}


/**
 * Makes sure enough rows and columns exist.
 */
function ensureSheetSize_(sheet) {
  const requiredColumns = 10;
  const requiredRows = 1000;

  if (sheet.getMaxColumns() < requiredColumns) {
    sheet.insertColumnsAfter(
      sheet.getMaxColumns(),
      requiredColumns - sheet.getMaxColumns()
    );
  }

  if (sheet.getMaxRows() < requiredRows) {
    sheet.insertRowsAfter(
      sheet.getMaxRows(),
      requiredRows - sheet.getMaxRows()
    );
  }
}


/**
 * Saves the exact worksheet where setup was run.
 */
function saveTrackerSheetId_(sheet) {
  PropertiesService.getDocumentProperties().setProperty(
    "POSH_TRACKER_SHEET_ID",
    String(sheet.getSheetId())
  );
}


/**
 * Returns the worksheet where the tracker was installed.
 */
function getTrackerSheet_(spreadsheet) {
  const savedSheetId =
    PropertiesService.getDocumentProperties().getProperty(
      "POSH_TRACKER_SHEET_ID"
    );

  if (!savedSheetId) {
    return spreadsheet.getActiveSheet();
  }

  const sheets = spreadsheet.getSheets();

  for (let i = 0; i < sheets.length; i++) {
    if (String(sheets[i].getSheetId()) === savedSheetId) {
      return sheets[i];
    }
  }

  return spreadsheet.getActiveSheet();
}


/**
 * Removes the previous history protection before resetting.
 */
function removeOldProtection_(sheet) {
  const protections = sheet.getProtections(
    SpreadsheetApp.ProtectionType.RANGE
  );

  protections.forEach(function(protection) {
    const description = protection.getDescription();

    if (
      description === POSH_TRACKER.protectionDescription ||
      description === "Protected Posh Listing History Log"
    ) {
      protection.remove();
    }
  });
}


/**
 * Clears only the tracker and history area.
 * Column A links are not touched.
 */
function clearOldTracker_(sheet) {
  const numberOfRows =
    sheet.getMaxRows() - POSH_TRACKER.historyHeaderRow + 1;

  sheet.getRange("E2:J7")
    .breakApart()
    .clearContent()
    .clearFormat()
    .clearDataValidations()
    .clearNote();

  sheet.getRange(
    POSH_TRACKER.historyHeaderRow,
    POSH_TRACKER.historyStartColumn,
    numberOfRows,
    POSH_TRACKER.historyColumns
  )
    .clearContent()
    .clearFormat()
    .clearDataValidations()
    .clearNote();
}


/**
 * Creates links remaining and account input area.
 */
function createTopTracker_(sheet) {
  // Links remaining
  sheet.getRange(POSH_TRACKER.linkCounterLabelCell)
    .setValue("Links Remaining")
    .setFontWeight("bold")
    .setBackground("#d9ead3")
    .setHorizontalAlignment("center")
    .setVerticalAlignment("middle")
    .setBorder(true, true, true, true, true, true);

  sheet.getRange(POSH_TRACKER.linkCounterCell)
    .setFormula('=COUNTIF(A:A,"http*")')
    .setFontWeight("bold")
    .setFontSize(12)
    .setBackground("#cfe2f3")
    .setHorizontalAlignment("center")
    .setVerticalAlignment("middle")
    .setBorder(true, true, true, true, true, true);

  // Blank separator row
  sheet.getRange("E3:J3")
    .clearContent()
    .clearFormat();

  // Account headers
  sheet.getRange("E4:G4")
    .setValues([[
      "Accounts",
      "Current Listings",
      "Last Updated"
    ]])
    .setFontWeight("bold")
    .setBackground("#d9ead3")
    .setHorizontalAlignment("center")
    .setVerticalAlignment("middle")
    .setBorder(true, true, true, true, true, true);

  // Account names
  sheet.getRange("E5:E6")
    .setValues([
      ["7"],
      ["m0"]
    ])
    .setFontWeight("bold")
    .setBackground("#f3f3f3")
    .setHorizontalAlignment("center")
    .setVerticalAlignment("middle")
    .setBorder(true, true, true, true, true, true);

  // Listing-count input cells
  sheet.getRange("F5:F6")
    .clearContent()
    .setBackground("#fff2cc")
    .setFontWeight("bold")
    .setFontSize(11)
    .setNumberFormat("0")
    .setHorizontalAlignment("center")
    .setVerticalAlignment("middle")
    .setBorder(true, true, true, true, true, true);

  // Timestamp cells
  sheet.getRange("G5:G6")
    .clearContent()
    .setBackground("#f3f3f3")
    .setHorizontalAlignment("center")
    .setVerticalAlignment("middle")
    .setBorder(true, true, true, true, true, true);

  const numberValidation = SpreadsheetApp.newDataValidation()
    .requireNumberGreaterThanOrEqualTo(0)
    .setAllowInvalid(false)
    .setHelpText("Enter the account's current total number of listings.")
    .build();

  sheet.getRange("F5:F6").setDataValidation(numberValidation);

  sheet.getRange("F5")
    .setNote("Enter the current total listing count for account 7.");

  sheet.getRange("F6")
    .setNote("Enter the current total listing count for account m0.");

  sheet.setColumnWidth(5, 155); // E
  sheet.setColumnWidth(6, 155); // F
  sheet.setColumnWidth(7, 175); // G
  sheet.setRowHeight(2, 28);
  sheet.setRowHeight(4, 28);
  sheet.setRowHeights(5, 2, 27);
}


/**
 * Creates clickable links that jump to rows 300 and 500.
 */
function createJumpLinks_(spreadsheet, sheet) {
  const baseUrl =
    spreadsheet.getUrl() +
    "#gid=" +
    sheet.getSheetId() +
    "&range=";

  const row300Link = SpreadsheetApp.newRichTextValue()
    .setText("GO TO ROW 300 — m0")
    .setLinkUrl(baseUrl + "A300")
    .build();

  const row500Link = SpreadsheetApp.newRichTextValue()
    .setText("GO TO ROW 500 — 7")
    .setLinkUrl(baseUrl + "A500")
    .build();

  sheet.getRange("H2")
    .setRichTextValue(row300Link)
    .setFontWeight("bold")
    .setBackground("#ead1dc")
    .setHorizontalAlignment("center")
    .setVerticalAlignment("middle")
    .setBorder(true, true, true, true, true, true)
    .setNote("Click to jump directly to row 300.");

  sheet.getRange("I2")
    .setRichTextValue(row500Link)
    .setFontWeight("bold")
    .setBackground("#fce5cd")
    .setHorizontalAlignment("center")
    .setVerticalAlignment("middle")
    .setBorder(true, true, true, true, true, true)
    .setNote("Click to jump directly to row 500.");

  sheet.setColumnWidth(8, 175); // H
  sheet.setColumnWidth(9, 175); // I
}


/**
 * Creates the protected history table.
 */
function createHistoryTable_(sheet) {
  const headers = [
    "Timestamp",
    "Account",
    "New Count",
    "Previous Count",
    "Change",
    "Links Remaining"
  ];

  sheet.getRange(
    POSH_TRACKER.historyHeaderRow,
    POSH_TRACKER.historyStartColumn,
    1,
    POSH_TRACKER.historyColumns
  )
    .setValues([headers])
    .setFontWeight("bold")
    .setBackground("#cfe2f3")
    .setHorizontalAlignment("center")
    .setVerticalAlignment("middle")
    .setBorder(true, true, true, true, true, true);

  sheet.setRowHeight(POSH_TRACKER.historyHeaderRow, 28);

  sheet.setColumnWidth(5, 165);
  sheet.setColumnWidth(6, 110);
  sheet.setColumnWidth(7, 130);
  sheet.setColumnWidth(8, 130);
  sheet.setColumnWidth(9, 110);
  sheet.setColumnWidth(10, 145);
}


/**
 * Runs automatically when F5 or F6 is edited.
 */
function onPoshListingEdit(e) {
  if (!e || !e.range) {
    return;
  }

  if (e.range.getNumRows() !== 1 || e.range.getNumColumns() !== 1) {
    return;
  }

  const spreadsheet = e.source;
  const trackerSheet = getTrackerSheet_(spreadsheet);
  const editedSheet = e.range.getSheet();

  if (editedSheet.getSheetId() !== trackerSheet.getSheetId()) {
    return;
  }

  const editedCell = e.range.getA1Notation();

  const account = POSH_TRACKER.accounts.find(function(item) {
    return item.inputCell === editedCell;
  });

  if (!account) {
    return;
  }

  const enteredValue = e.range.getValue();

  if (enteredValue === "" || enteredValue === null) {
    return;
  }

  const newCount = Number(enteredValue);

  if (
    !Number.isFinite(newCount) ||
    newCount < 0 ||
    !Number.isInteger(newCount)
  ) {
    e.range.setValue(
      typeof e.oldValue !== "undefined" ? e.oldValue : ""
    );

    spreadsheet.toast(
      "Enter a whole number of zero or greater.",
      "Invalid Listing Count",
      5
    );

    return;
  }

  const previousCount = getLatestCountForAccount_(
    trackerSheet,
    account.accountName
  );

  const change =
    previousCount === ""
      ? ""
      : newCount - Number(previousCount);

  SpreadsheetApp.flush();

  const linksRemaining =
    trackerSheet
      .getRange(POSH_TRACKER.linkCounterCell)
      .getValue();

  addNewestHistoryEntry_(
    trackerSheet,
    account.accountName,
    newCount,
    previousCount,
    change,
    linksRemaining
  );

  trackerSheet
    .getRange(account.lastUpdatedCell)
    .setValue(new Date())
    .setNumberFormat("M/d/yyyy h:mm AM/PM");

  spreadsheet.toast(
    "Listing count saved for account " + account.accountName + ".",
    "Count Logged",
    4
  );
}


/**
 * Finds the newest recorded count for the selected account.
 * Since newest entries are at the top, it searches from row 9 downward.
 */
function getLatestCountForAccount_(sheet, accountName) {
  const lastHistoryRow = getLastHistoryRow_(sheet);

  if (lastHistoryRow < POSH_TRACKER.historyFirstDataRow) {
    return "";
  }

  const numberOfRows =
    lastHistoryRow - POSH_TRACKER.historyFirstDataRow + 1;

  const historyValues = sheet.getRange(
    POSH_TRACKER.historyFirstDataRow,
    POSH_TRACKER.historyStartColumn,
    numberOfRows,
    POSH_TRACKER.historyColumns
  ).getValues();

  for (let i = 0; i < historyValues.length; i++) {
    const recordedAccount = String(historyValues[i][1]).trim();

    if (recordedAccount === String(accountName)) {
      return historyValues[i][2];
    }
  }

  return "";
}


/**
 * Places the newest entry in row 9 and moves older entries downward.
 * Only columns E:J move; column A links are not shifted.
 */
function addNewestHistoryEntry_(
  sheet,
  accountName,
  newCount,
  previousCount,
  change,
  linksRemaining
) {
  const firstDataRow = POSH_TRACKER.historyFirstDataRow;
  const lastHistoryRow = getLastHistoryRow_(sheet);

  if (lastHistoryRow >= firstDataRow) {
    if (lastHistoryRow >= sheet.getMaxRows()) {
      sheet.insertRowsAfter(sheet.getMaxRows(), 1);
    }

    const existingRowCount =
      lastHistoryRow - firstDataRow + 1;

    const existingValues = sheet.getRange(
      firstDataRow,
      POSH_TRACKER.historyStartColumn,
      existingRowCount,
      POSH_TRACKER.historyColumns
    ).getValues();

    sheet.getRange(
      firstDataRow + 1,
      POSH_TRACKER.historyStartColumn,
      existingRowCount,
      POSH_TRACKER.historyColumns
    ).setValues(existingValues);
  }

  const newHistoryRow = [
    new Date(),
    accountName,
    newCount,
    previousCount,
    change,
    linksRemaining
  ];

  sheet.getRange(
    firstDataRow,
    POSH_TRACKER.historyStartColumn,
    1,
    POSH_TRACKER.historyColumns
  )
    .setValues([newHistoryRow])
    .setHorizontalAlignment("center")
    .setVerticalAlignment("middle")
    .setBorder(true, true, true, true, true, true);

  sheet.getRange(firstDataRow, POSH_TRACKER.historyStartColumn)
    .setNumberFormat("M/d/yyyy h:mm AM/PM");

  sheet.getRange(
    firstDataRow,
    POSH_TRACKER.historyStartColumn + 2,
    1,
    4
  ).setNumberFormat("0");
}


/**
 * Finds the final populated history row.
 */
function getLastHistoryRow_(sheet) {
  const firstDataRow = POSH_TRACKER.historyFirstDataRow;
  const totalRows = sheet.getMaxRows() - firstDataRow + 1;

  const timestampValues = sheet.getRange(
    firstDataRow,
    POSH_TRACKER.historyStartColumn,
    totalRows,
    1
  ).getValues();

  for (let i = timestampValues.length - 1; i >= 0; i--) {
    if (timestampValues[i][0] !== "") {
      return firstDataRow + i;
    }
  }

  return firstDataRow - 1;
}


/**
 * Protects the history so the VA cannot edit it.
 */
function protectHistory_(sheet) {
  removeOldProtection_(sheet);

  const numberOfRows =
    sheet.getMaxRows() - POSH_TRACKER.historyHeaderRow + 1;

  const protectedRange = sheet.getRange(
    POSH_TRACKER.historyHeaderRow,
    POSH_TRACKER.historyStartColumn,
    numberOfRows,
    POSH_TRACKER.historyColumns
  );

  const protection = protectedRange.protect();

  protection
    .setDescription(POSH_TRACKER.protectionDescription)
    .setWarningOnly(false);

  const owner = Session.getEffectiveUser();

  protection.addEditor(owner);

  protection.getEditors().forEach(function(editor) {
    if (editor.getEmail() !== owner.getEmail()) {
      protection.removeEditor(editor);
    }
  });

  if (protection.canDomainEdit()) {
    protection.setDomainEdit(false);
  }
}


/**
 * Replaces any previous tracker edit trigger.
 */
function createEditTrigger_() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  const triggers = ScriptApp.getProjectTriggers();

  triggers.forEach(function(trigger) {
    if (trigger.getHandlerFunction() === "onPoshListingEdit") {
      ScriptApp.deleteTrigger(trigger);
    }
  });

  ScriptApp.newTrigger("onPoshListingEdit")
    .forSpreadsheet(spreadsheet)
    .onEdit()
    .create();
}