const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const background = fs.readFileSync(path.join(root, 'extension', 'background.js'), 'utf8');
const popupHtml = fs.readFileSync(path.join(root, 'extension', 'popup.html'), 'utf8');
const popupJs = fs.readFileSync(path.join(root, 'extension', 'popup.js'), 'utf8');
const publicConfig = fs.readFileSync(path.join(root, 'extension', 'config.example.js'), 'utf8');
const installer = fs.readFileSync(path.join(root, 'bootstrap-install.ps1'), 'utf8');

test('dashboard operations use saved Chrome-profile setup and migrate legacy local config only when needed', () => {
  assert.match(background, /async function getDashboardConfig\(\)\s*\{[\s\S]*?storageGet[\s\S]*?await seedDashboardSetupFromLocalConfig\(\);[\s\S]*?storageGet/);
  assert.match(background, /source: 'saved-profile'/);
  assert.match(background, /let source = 'private-package'/);
  assert.match(background, /source = 'bundled-default'/);
  assert.match(background, /Dashboard setup code is missing\. Open GLDN Ops Setup and choose Connect Dashboard\./);
});

test('saved dashboard setup is checked across every extension lifecycle', () => {
  assert.match(background, /onInstalled\.addListener\(\(details\) => \{\s*seedAutomaticDashboardSetup\(`/);
  assert.match(background, /onStartup\.addListener\(\(\) => \{\s*seedAutomaticDashboardSetup\('chrome-startup'\)/);
  assert.match(background, /seedAutomaticDashboardSetup\('worker-start'\);/);
  assert.match(popupJs, /async function initializePopup\(\) \{[\s\S]*?await ensureAutomaticDashboardSetup\(\);/);
});

test('popup has saved-profile status and a pasteable inline connection field', () => {
  assert.match(popupHtml, /id="dashboardAutoSetup"/);
  assert.match(popupHtml, /id="repairDashboardSetup"[^>]*>Connect Dashboard<\/button>/);
  assert.doesNotMatch(popupHtml, /dashboardSetupKey|Save Setup Code|Clear Setup Code/);
  assert.doesNotMatch(popupJs, /clearDashboardSetup|dashboardSetupKeyInput/);
  assert.match(popupJs, /type: 'seedDashboardSetupFromLocalConfig'/);
  assert.match(popupHtml, /id="dashboardConnectionCode" type="password"/);
  assert.match(popupJs, /async function saveDashboardConnection\(\)/);
  assert.doesNotMatch(popupJs, /\bU\.|window\.prompt/);
});

test('installer preserves saved setup and new profiles use the approved default', () => {
  assert.match(installer, /bundled dashboard connection loads automatically in new Chrome profiles/);
  assert.match(installer, /Existing saved connections are preserved across extension updates/);
  assert.doesNotMatch(installer, /Read-Host\s+"Enter the private dashboard setup code/);
  assert.doesNotMatch(installer, /automatic dashboard connection included in this private package/i);
  assert.match(publicConfig, /dashboardKey:\s*""/);
});
