GLDN Ops v3.12.3

v3.12.3 cross-profile cost-reconciliation candidate:
- Requires one permanent Amazon profile name before an eBay or Poshmark missing-cost run begins.
- Records that profile on every reviewed result and skips rows that the same Amazon profile already checked.
- Directs unresolved rows to another signed-in Amazon profile instead of repeating the same 100 orders.
- Keeps the exact count-bound approval before any reviewed cost results sync to the shared dashboard.
- Dashboard deployment revision 45 accepts and filters the profile-attempt evidence.
- Publishes 166 source-linked, human-reviewed rules derived from official eBay listing policies.
- Covers product safety, surveillance, lockpicking, vehicle parts, government and police items, food, alcohol, payment cards, military items, animal products, plants and seeds, and illegal-activity items.
- Includes false-positive protections for ordinary products such as kitchen spoons, wine-glass racks, ivory-color goods, Slim Jim snacks, and ordinary chargers.
- Keeps Ready to copy, Needs review, and Blocked outputs separate and preserves the original input order.
- Fails closed when reviewed rules are empty or unavailable.
- Does not use an eBay API, submit a listing, or claim that a Ready result is eBay approval.
- Signed-in Profile 2 Discord evidence and final live release verification remain required before publication.
