# GLDN Product Hunter v0.2.0

## Added

- Complete read-only eBay Active Listings scan with resumable inactive-tab pagination.
- Final total and unique-item verification before a listing index can protect a hunt.
- Active Listings CSV import fallback using a structured CSV parser.
- Exact eComSniper SKU/ASIN duplicate exclusion.
- Exact normalized-title duplicate review.
- Computer-bound listing indexes so one eBay account's data cannot protect another account by mistake.
- Visible scan progress, pause/resume/stop, worker-tab access, index age, and indexed totals.

## Safety

- The eBay scanner never clicks, selects, edits, or submits listings.
- A partial scan never replaces the previous verified index.
- Protected hunts cannot start without a verified index for the selected computer.
- No eBay API, debugger permission, native helper, or broad all-sites permission is used.
