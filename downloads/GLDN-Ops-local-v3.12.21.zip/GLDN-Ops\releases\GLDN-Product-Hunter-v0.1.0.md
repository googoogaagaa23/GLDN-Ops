# GLDN Product Hunter v0.1.0

Initial standalone Product Hunter release.

## Added

- Normal Amazon keyword search through a signed-in Chrome session.
- Resumable inactive-tab search and detail queue.
- 175 reviewed official eBay policy rules.
- Ready, Review, Blocked, Excluded, Incomplete, and Queued decisions.
- Fashion, sponsored, price, rating, review-count, stock, duplicate, and 60-day reuse filters.
- Copy-only Ready link handoff to EcomSniper.
- Audit CSV, run log, pause, resume, stop, reset, and CAPTCHA pause.
- Amazon-only website permission with no eBay API, debugger, broad host, or native helper.
