GLDN Ops v3.12.5

v3.12.5 reconciliation and listing-preflight candidate:
- Requires one permanent Amazon profile name before an eBay or Poshmark missing-cost run begins.
- Displays and records the exact supplier profile plus the live pending review count.
- Skips unresolved rows already attempted by that permanent profile and leaves misses open for another signed-in Amazon profile.
- Keeps exact count-bound approval before any reviewed cost results sync to the shared dashboard.
- Preserves saved-note profit separately from independent Amazon-order profit for discrepancy review.
- Publishes 175 source-linked, human-reviewed rules derived from official eBay listing policies.
- Adds a Ready-only Product Hunter-to-Bulk Poster handoff using canonical Amazon links.
- Keeps Needs review, Blocked, duplicate, opaque, and non-Amazon inputs out of the Bulk Poster clipboard.
- Fails closed when reviewed rules are empty or unavailable.
- Does not use an eBay API, submit a listing, start Bulk Poster, or claim that a Ready result is eBay approval.
- Delivers large approved profit batches with a bounded 90-second dashboard wait so a slow Apps Script response does not strand an already-accepted batch.
- Live Profile 2 proof separated Ready, Review, and Block samples, copied only one canonical Ready Amazon URL, and opened the exact EcomSniper Bulk Poster page without starting it.
- Live Profile 2 proof opened the exact EcomSniper Scanner and Product Hunter pages, reported only observable tab lifecycle, and stopped only the GLDN-opened tab.
- The approved 29-row F9132 cost review is durably synced; zero rows remain open for that Amazon profile and the dashboard retry queue is empty.
- Other signed-in Amazon profiles remain separate reconciliation gates.
