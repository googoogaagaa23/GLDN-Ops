(function attachEbayProfitCore(root, factory) {
  const api = factory();
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (root) root.GLDN_EBAY_PROFIT_CORE = api;
})(typeof globalThis !== "undefined" ? globalThis : this, () => {
  const STATE_VERSION = 1;
  const MONTH_KEY_PATTERN = /^\d{4}-(?:0[1-9]|1[0-2])$/;

  function text(value) {
    return String(value ?? "").replace(/\s+/g, " ").trim();
  }

  function unique(values) {
    return [...new Set((values || []).map(text).filter(Boolean))];
  }

  function money(value) {
    if (typeof value === "number") return Number.isFinite(value) ? value : null;
    const cleaned = text(value).replace(/[$,\s]/g, "");
    if (!/^-?\d+(?:\.\d{1,2})?$/.test(cleaned)) return null;
    const parsed = Number(cleaned);
    return Number.isFinite(parsed) ? parsed : null;
  }

  function normalizeMonthKey(value) {
    const normalized = text(value);
    return MONTH_KEY_PATTERN.test(normalized) ? normalized : "";
  }

  function monthLabel(value) {
    const monthKey = normalizeMonthKey(value);
    if (!monthKey) return "";
    const [year, month] = monthKey.split("-").map(Number);
    return new Date(year, month - 1, 1).toLocaleDateString("en-US", {
      month: "long",
      year: "numeric"
    });
  }

  function parseDate(value, targetMonthKey = "") {
    const raw = text(value);
    if (!raw) return null;
    const targetYear = Number(normalizeMonthKey(targetMonthKey).slice(0, 4)) || new Date().getFullYear();
    const cleaned = raw
      .replace(/\b(?:PDT|PST|CDT|CST|EDT|EST|UTC)\b/gi, "")
      .replace(/\bat\b/gi, " ")
      .replace(/\s+/g, " ")
      .trim();
    const hasYear = /\b(?:19|20)\d{2}\b/.test(cleaned);
    const candidate = hasYear ? cleaned : `${cleaned}, ${targetYear}`;
    const parsed = new Date(candidate);
    if (!Number.isFinite(parsed.getTime())) return null;
    return new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
  }

  function isoDate(value, targetMonthKey = "") {
    const parsed = parseDate(value, targetMonthKey);
    if (!parsed) return "";
    return [
      parsed.getFullYear(),
      String(parsed.getMonth() + 1).padStart(2, "0"),
      String(parsed.getDate()).padStart(2, "0")
    ].join("-");
  }

  function monthKeyForDate(value, targetMonthKey = "") {
    return isoDate(value, targetMonthKey).slice(0, 7);
  }

  function extractOrderDateText(value) {
    const source = text(value);
    if (!source) return "";
    const month = "(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)";
    const labeled = source.match(new RegExp(`(?:date sold|sold|date paid|paid|order date)\\s*:?\\s*(${month}\\s+\\d{1,2}(?:,?\\s+\\d{4})?)`, "i"));
    if (labeled) return labeled[1];
    const visibleRowDate = source.match(new RegExp(`\\b(${month}\\s+\\d{1,2}(?:,?\\s+\\d{4})?)\\b`, "i"));
    return visibleRowDate ? visibleRowDate[1] : "";
  }

  function classifyOrdersIndexPage(input = {}) {
    const heading = text(input.heading).toLowerCase();
    const selectedStatus = text(input.selectedStatus).toLowerCase();
    const bodyText = text(input.bodyText).toLowerCase();
    const detailLinkCount = Math.max(0, Number(input.detailLinkCount || 0));
    const awaitingShipment = heading.includes("awaiting shipment")
      || selectedStatus.includes("awaiting shipment");
    const allOrders = !awaitingShipment && (
      selectedStatus === "all orders"
      || heading === "all orders"
      || heading === "manage orders"
      || heading === "manage all orders"
    );
    const explicitEmpty = /\bresults?\s*:\s*0(?:\s*-\s*0)?\s+of\s+0\b/.test(bodyText)
      || /\b(?:no|zero)\s+(?:matching\s+)?orders?\s+(?:found|to show|available)\b/.test(bodyText)
      || /\bthere are no (?:matching )?orders?\b/.test(bodyText);
    const interrupted = /\bpardon our interruption\b|\bsecurity challenge\b|\bverify (?:that )?(?:it'?s|you are) you\b|\bcaptcha\b|\bthink you are a bot\b/.test(bodyText);
    const ready = allOrders && !interrupted && (detailLinkCount > 0 || explicitEmpty);
    let reason = "";
    if (interrupted) reason = "eBay displayed an interruption or identity challenge.";
    else if (awaitingShipment) reason = "eBay reopened the persisted Awaiting Shipment view.";
    else if (!allOrders) reason = "The worker could not verify eBay's All orders view.";
    else if (!ready) reason = "The All orders page did not render order rows or an explicit empty result.";
    return {
      heading,
      selectedStatus,
      detailLinkCount,
      awaitingShipment,
      allOrders,
      explicitEmpty,
      interrupted,
      ready,
      reason
    };
  }

  function parseSavedNote(value) {
    const note = text(value);
    if (!note) return { ok: false, status: "missing-note", error: "No saved eBay note was found." };
    const match = note.match(/^\$?(-?[\d,]+(?:\.\d{1,2})?)\s+-\s+\$?([\d,]+(?:\.\d{1,2})?)\s+-\s+(.+?)\s+-\s+(.+)$/);
    if (!match) {
      return {
        ok: false,
        status: "malformed-note",
        error: "The saved note does not match earnings - Amazon cost - profile - ETA."
      };
    }
    const marketplaceEarnings = money(match[1]);
    const supplierTotal = money(match[2]);
    const supplierProfile = text(match[3]);
    const eta = text(match[4]);
    if (marketplaceEarnings === null || marketplaceEarnings < 0) {
      return { ok: false, status: "malformed-note", error: "The saved note has an invalid eBay earnings amount." };
    }
    if (supplierTotal === null || supplierTotal <= 0) {
      return { ok: false, status: "malformed-note", error: "The saved note has an invalid Amazon cost." };
    }
    if (!supplierProfile || !eta) {
      return { ok: false, status: "malformed-note", error: "The saved note is missing the Amazon profile or ETA." };
    }
    return {
      ok: true,
      note,
      marketplaceEarnings: Number(marketplaceEarnings.toFixed(2)),
      supplierTotal: Number(supplierTotal.toFixed(2)),
      supplierProfile,
      eta
    };
  }

  function orderKey(record) {
    return text(record?.orderNumber);
  }

  function createRun(options = {}) {
    const monthKey = normalizeMonthKey(options.monthKey);
    if (!monthKey) throw new Error("A valid YYYY-MM month is required for an eBay profit run.");
    const now = text(options.now) || new Date().toISOString();
    return {
      stateVersion: STATE_VERSION,
      runId: text(options.runId) || `ebay-profit-${monthKey}-${Date.now()}`,
      extensionVersion: text(options.extensionVersion),
      monthKey,
      monthLabel: monthLabel(monthKey),
      maxOrders: Math.max(1, Math.min(5000, Number(options.maxOrders || 5000))),
      computerLabel: text(options.computerLabel),
      accountLabel: text(options.accountLabel),
      active: true,
      stopRequested: false,
      phase: "index-orders",
      startedAt: now,
      updatedAt: now,
      ownerTabId: Number.isInteger(options.ownerTabId) ? options.ownerTabId : null,
      ownerWindowId: Number.isInteger(options.ownerWindowId) ? options.ownerWindowId : null,
      workerTabId: null,
      pagesScanned: 0,
      pageFingerprints: [],
      orders: [],
      detailIndex: 0,
      results: [],
      syncedOrderNumbers: [],
      errors: []
    };
  }

  function mergeOrdersPage(run, records, options = {}) {
    const byOrder = new Map((run.orders || []).map((record) => [orderKey(record), { ...record }]));
    let sawOlder = false;
    let sawTarget = false;
    let newestMonth = "";
    const pageOrders = [];
    (records || []).forEach((raw) => {
      const orderNumber = orderKey(raw);
      if (!orderNumber) return;
      const orderDate = isoDate(raw.orderDate, run.monthKey);
      const recordMonth = orderDate.slice(0, 7);
      if (!recordMonth) return;
      if (!newestMonth || recordMonth > newestMonth) newestMonth = recordMonth;
      if (recordMonth < run.monthKey) {
        sawOlder = true;
        return;
      }
      if (recordMonth !== run.monthKey) return;
      sawTarget = true;
      const record = {
        ...(byOrder.get(orderNumber) || {}),
        ...raw,
        orderNumber,
        orderDate,
        pageUrl: text(raw.pageUrl)
      };
      byOrder.set(orderNumber, record);
      pageOrders.push(record);
    });
    const fingerprint = unique((records || []).map((record) => `${orderKey(record)}:${text(record?.orderDate)}`)).sort().join("|");
    const repeatedPage = Boolean(fingerprint && (run.pageFingerprints || []).includes(fingerprint));
    const orders = [...byOrder.values()].slice(0, run.maxOrders);
    const reachedLimit = orders.length >= run.maxOrders;
    const noNextPage = options.hasNext === false;
    const targetCannotAppear = !sawTarget && newestMonth && newestMonth < run.monthKey;
    const indexComplete = reachedLimit || sawOlder || targetCannotAppear || noNextPage || repeatedPage;
    return {
      ...run,
      orders,
      pagesScanned: Number(run.pagesScanned || 0) + 1,
      pageFingerprints: fingerprint && !repeatedPage
        ? [...(run.pageFingerprints || []), fingerprint]
        : [...(run.pageFingerprints || [])],
      phase: indexComplete ? "capture-details" : "index-orders",
      detailIndex: indexComplete ? 0 : Number(run.detailIndex || 0),
      lastPageOrderCount: pageOrders.length,
      updatedAt: new Date().toISOString()
    };
  }

  function buildResult(run, sale, detail = {}) {
    const orderNumber = orderKey(detail) || orderKey(sale);
    const orderDate = isoDate(detail.orderDate || sale.orderDate, run.monthKey);
    const base = {
      orderNumber,
      orderDate,
      itemTitle: text(detail.itemTitle || sale.itemTitle),
      pageUrl: text(detail.pageUrl || sale.pageUrl),
      note: text(detail.note),
      marketplaceEarnings: money(detail.marketplaceEarnings),
      skus: unique(detail.skus),
      asins: unique(detail.asins).map((value) => value.toUpperCase()).filter((value) => /^[A-Z0-9]{10}$/.test(value)),
      capturedAt: text(detail.capturedAt) || new Date().toISOString()
    };
    if (!orderNumber || (sale?.orderNumber && orderNumber !== sale.orderNumber)) {
      return { ...base, status: "order-mismatch", reason: "The order detail page did not match the indexed eBay order." };
    }
    if (!orderDate || orderDate.slice(0, 7) !== run.monthKey) {
      return { ...base, status: "date-mismatch", reason: "The order date is missing or outside the selected month." };
    }
    const visibleEarnings = money(detail.marketplaceEarnings);
    if (visibleEarnings === null || visibleEarnings < 0) {
      return { ...base, status: "missing-earnings", reason: "eBay Order earnings could not be read from the order detail page." };
    }
    const parsedNote = parseSavedNote(detail.note);
    if (!parsedNote.ok) return { ...base, status: parsedNote.status, reason: parsedNote.error };
    if (Math.abs(parsedNote.marketplaceEarnings - visibleEarnings) > 0.011) {
      return {
        ...base,
        status: "earnings-mismatch",
        reason: `The saved-note earnings $${parsedNote.marketplaceEarnings.toFixed(2)} do not match eBay Order earnings $${visibleEarnings.toFixed(2)}.`,
        noteEarnings: parsedNote.marketplaceEarnings,
        visibleEarnings: Number(visibleEarnings.toFixed(2))
      };
    }
    const profit = Number((visibleEarnings - parsedNote.supplierTotal).toFixed(2));
    const skus = unique(detail.skus);
    const asins = unique(detail.asins).map((value) => value.toUpperCase()).filter((value) => /^[A-Z0-9]{10}$/.test(value));
    const record = {
      platform: "eBay",
      computerLabel: run.computerLabel,
      accountLabel: run.accountLabel,
      ebayAccountLabel: run.accountLabel,
      orderNumber,
      itemTitle: base.itemTitle,
      marketplaceEarnings: Number(visibleEarnings.toFixed(2)),
      marketplaceSoldPrice: null,
      supplier: "Amazon",
      supplierTotal: parsedNote.supplierTotal,
      supplierProfile: parsedNote.supplierProfile,
      eta: parsedNote.eta,
      profit,
      margin: visibleEarnings > 0 ? profit / visibleEarnings : null,
      sku: skus.join(", "),
      supplierItemIds: asins.join(", "),
      supplierOrderNumber: "",
      supplierMatchSource: "saved-ebay-note",
      supplierPageUrl: "",
      supplierItemEvidence: `Existing eBay note verified against visible Order earnings: ${parsedNote.note}`,
      orderDate,
      orderStatus: text(detail.orderStatus),
      earningsStatus: "Verified against eBay Order earnings",
      source: "ebay-monthly-profit-note",
      note: parsedNote.note,
      capturedAt: base.capturedAt,
      pageUrl: base.pageUrl
    };
    return { ...base, status: "exact", record };
  }

  function mergeDetail(run, detail) {
    const sale = (run.orders || [])[Number(run.detailIndex || 0)] || {};
    const result = buildResult(run, sale, detail);
    const resultsByOrder = new Map((run.results || []).map((entry) => [orderKey(entry), entry]));
    if (result.orderNumber) resultsByOrder.set(result.orderNumber, result);
    const detailIndex = Math.min((run.orders || []).length, Number(run.detailIndex || 0) + 1);
    return {
      ...run,
      results: [...resultsByOrder.values()],
      detailIndex,
      phase: detailIndex >= (run.orders || []).length ? "review" : "capture-details",
      active: detailIndex < (run.orders || []).length,
      updatedAt: new Date().toISOString()
    };
  }

  function exactResults(run) {
    return (run?.results || []).filter((result) => result?.status === "exact" && result.record);
  }

  function unsyncedExactResults(run) {
    const synced = new Set((run?.syncedOrderNumbers || []).map(String));
    return exactResults(run).filter((result) => !synced.has(String(result.orderNumber || "")));
  }

  function unsyncedReviewResults(run) {
    const synced = new Set((run?.syncedOrderNumbers || []).map(String));
    return (run?.results || []).filter((result) => result?.orderNumber && !synced.has(String(result.orderNumber)));
  }

  function buildReconciliationRecord(run, result) {
    const exact = result?.status === "exact" && result.record ? result.record : null;
    const visibleEarnings = money(exact?.marketplaceEarnings ?? result?.marketplaceEarnings ?? result?.visibleEarnings);
    const noteCost = exact ? money(exact.supplierTotal) : null;
    const noteProfit = exact ? money(exact.profit) : null;
    const skus = unique(exact?.sku ? String(exact.sku).split(/[,|]/) : result?.skus);
    const asins = unique(exact?.supplierItemIds ? String(exact.supplierItemIds).split(/[,|]/) : result?.asins)
      .map((value) => value.toUpperCase())
      .filter((value) => /^[A-Z0-9]{10}$/.test(value));
    let reason = "Waiting for an independent exact Amazon order-item match.";
    if (!asins.length) reason = "The eBay SKU did not decode to an exact Amazon ASIN.";
    else if (!exact) reason = `${text(result?.reason) || "The saved-note profit is unresolved."} Independent Amazon matching is still available.`;
    return {
      platform: "eBay",
      computerLabel: text(run?.computerLabel),
      accountLabel: text(run?.accountLabel),
      ebayAccountLabel: text(run?.accountLabel),
      monthKey: normalizeMonthKey(run?.monthKey) || text(result?.orderDate).slice(0, 7),
      orderNumber: text(result?.orderNumber),
      itemTitle: text(exact?.itemTitle || result?.itemTitle),
      marketplaceEarnings: visibleEarnings,
      marketplaceSoldPrice: null,
      orderDate: text(exact?.orderDate || result?.orderDate),
      orderStatus: text(exact?.orderStatus),
      earningsStatus: visibleEarnings === null ? "Missing eBay Order earnings" : "Read from eBay Order earnings",
      sku: skus.join(", "),
      skus,
      supplierItemIds: asins.join(", "),
      asins,
      noteStatus: exact ? "verified" : text(result?.status || "unresolved"),
      noteSupplierTotal: noteCost,
      noteSupplierProfile: text(exact?.supplierProfile),
      noteProfit,
      noteText: text(exact?.note || result?.note),
      supplierTotal: null,
      supplierProfile: "",
      supplierOrderNumber: "",
      supplierMatchSource: "",
      supplierPageUrl: "",
      supplierItemEvidence: "",
      profit: null,
      margin: null,
      status: asins.length ? "amazon-pending" : "missing-sku",
      reason,
      pageUrl: text(exact?.pageUrl || result?.pageUrl),
      attemptedSupplierProfiles: [],
      source: "ebay-monthly-profit-reconciliation",
      capturedAt: text(result?.capturedAt) || new Date().toISOString()
    };
  }

  function reviewRecords(run) {
    return unsyncedReviewResults(run).map((result) => buildReconciliationRecord(run, result));
  }

  function approvalToken(run) {
    return `APPROVE SYNC EBAY ${run?.monthKey || "YYYY-MM"} ${unsyncedReviewResults(run).length}`;
  }

  function summary(run) {
    if (!run) return null;
    const exact = exactResults(run);
    const totals = exact.reduce((aggregate, result) => {
      aggregate.earnings += Number(result.record.marketplaceEarnings || 0);
      aggregate.amazonCost += Number(result.record.supplierTotal || 0);
      aggregate.profit += Number(result.record.profit || 0);
      return aggregate;
    }, { earnings: 0, amazonCost: 0, profit: 0 });
    Object.keys(totals).forEach((key) => { totals[key] = Number(totals[key].toFixed(2)); });
    const statuses = {};
    (run.results || []).forEach((result) => { statuses[result.status] = Number(statuses[result.status] || 0) + 1; });
    return {
      runId: run.runId,
      phase: run.phase,
      monthKey: run.monthKey,
      monthLabel: run.monthLabel,
      pagesScanned: Number(run.pagesScanned || 0),
      ordersIndexed: (run.orders || []).length,
      detailsCaptured: (run.results || []).length,
      exact: exact.length,
      unresolved: (run.results || []).length - exact.length,
      unsyncedExact: unsyncedExactResults(run).length,
      unsyncedReviewed: unsyncedReviewResults(run).length,
      synced: (run.syncedOrderNumbers || []).length,
      statuses,
      totals,
      approvalToken: approvalToken(run),
      active: run.active === true,
      pausedReason: text(run.pausedReason)
    };
  }

  function compactControlRecord(run) {
    if (!run) return null;
    const compact = summary(run);
    return {
      active: run.active === true,
      phase: run.phase,
      runId: run.runId,
      monthKey: run.monthKey,
      workerTabId: run.workerTabId,
      ownerTabId: run.ownerTabId,
      updatedAt: run.updatedAt,
      summary: compact,
      errors: (run.errors || []).slice(-10)
    };
  }

  return Object.freeze({
    STATE_VERSION,
    normalizeMonthKey,
    monthLabel,
    classifyOrdersIndexPage,
    isoDate,
    monthKeyForDate,
    extractOrderDateText,
    parseSavedNote,
    createRun,
    mergeOrdersPage,
    buildResult,
    mergeDetail,
    exactResults,
    unsyncedExactResults,
    unsyncedReviewResults,
    buildReconciliationRecord,
    reviewRecords,
    approvalToken,
    summary,
    compactControlRecord
  });
});
