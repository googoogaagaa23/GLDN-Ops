(() => {
  const CORE = globalThis.GLDN_EBAY_PROFIT_CORE;
  const $ = (id) => document.getElementById(id);
  let state = null;
  let summary = null;
  let filter = "all";

  function priorMonthKey() {
    const now = new Date();
    const prior = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    return `${prior.getFullYear()}-${String(prior.getMonth() + 1).padStart(2, "0")}`;
  }

  function runtimeMessage(message, timeoutMs = 120000) {
    return new Promise((resolve) => {
      let settled = false;
      const timer = setTimeout(() => {
        if (!settled) resolve({ ok: false, error: "GLDN Ops did not answer before the timeout." });
      }, timeoutMs);
      chrome.runtime.sendMessage(message, (response) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        const error = chrome.runtime.lastError?.message;
        resolve(error ? { ok: false, error } : (response || { ok: false, error: "No response." }));
      });
    });
  }

  function money(value) {
    const number = Number(value || 0);
    return number.toLocaleString(undefined, { style: "currency", currency: "USD" });
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>'"]/g, (character) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;"
    })[character]);
  }

  function setNotice(message, tone = "neutral") {
    $("notice").textContent = message;
    $("notice").dataset.tone = tone;
  }

  function displayStatus(value) {
    return String(value || "unknown").replace(/-/g, " ");
  }

  function rowMarkup(result) {
    const exact = result.status === "exact" && result.record;
    const record = result.record || {};
    const profit = Number(record.profit || 0);
    const visibleEarnings = exact ? record.marketplaceEarnings : result.marketplaceEarnings;
    const issue = exact
      ? `${escapeHtml(record.supplierProfile || "Unknown")}<br><small>${escapeHtml(record.eta || "")}</small>`
      : escapeHtml(result.reason || "Needs manual review");
    return `
      <tr data-kind="${exact ? "exact" : "unresolved"}">
        <td>${escapeHtml(result.orderDate || record.orderDate || "")}</td>
        <td><a class="order-link" href="${escapeHtml(result.pageUrl || record.pageUrl || "#")}" target="_blank" rel="noreferrer">${escapeHtml(result.orderNumber || "Unknown")}</a></td>
        <td>${escapeHtml(result.itemTitle || record.itemTitle || "")}</td>
        <td><span class="status ${exact ? "exact" : "unresolved"}">${escapeHtml(exact ? "Exact" : displayStatus(result.status))}</span></td>
        <td class="money">${Number.isFinite(Number(visibleEarnings)) ? money(visibleEarnings) : "-"}</td>
        <td class="money">${exact ? money(record.supplierTotal) : "-"}</td>
        <td class="money ${exact ? (profit >= 0 ? "profit-positive" : "profit-negative") : ""}">${exact ? money(profit) : "-"}</td>
        <td>${issue}</td>
      </tr>`;
  }

  function renderRows() {
    const results = Array.isArray(state?.results) ? state.results : [];
    const visible = results.filter((result) => {
      const kind = result.status === "exact" && result.record ? "exact" : "unresolved";
      return filter === "all" || filter === kind;
    });
    $("resultsBody").innerHTML = visible.length
      ? visible.sort((left, right) => String(right.orderDate || "").localeCompare(String(left.orderDate || ""))).map(rowMarkup).join("")
      : `<tr><td colspan="8" class="empty">${results.length ? "No rows match this filter." : "No order rows collected yet."}</td></tr>`;
  }

  function render() {
    summary = CORE.summary(state);
    const totals = summary?.totals || {};
    $("identity").textContent = state
      ? `Computer ${state.computerLabel || "?"} / ${state.accountLabel || "Unknown eBay"}`
      : "No saved run";
    $("ordersIndexed").textContent = Number(summary?.ordersIndexed || 0).toLocaleString();
    $("detailsCaptured").textContent = Number(summary?.detailsCaptured || 0).toLocaleString();
    $("exactCount").textContent = Number(summary?.exact || 0).toLocaleString();
    $("unresolvedCount").textContent = Number(summary?.unresolved || 0).toLocaleString();
    $("earningsTotal").textContent = money(totals.earnings);
    $("amazonTotal").textContent = money(totals.amazonCost);
    $("profitTotal").textContent = money(totals.profit);
    $("reviewCaption").textContent = state
      ? `${state.monthLabel || state.monthKey}: ${displayStatus(state.phase)}. ${Number(summary?.pagesScanned || 0).toLocaleString()} order pages scanned.`
      : "Start a month to collect orders.";

    const active = state?.active === true;
    $("startRun").disabled = active || state?.phase === "review";
    $("resumeRun").disabled = !state || active || ["review", "completed"].includes(state.phase);
    $("pauseRun").disabled = !active;
    $("resetRun").disabled = !state;
    $("monthKey").disabled = active;

    if (!state) setNotice("No monthly run saved.");
    else if (state.phase === "review") setNotice(`Review ready: ${summary.exact} note-based profit rows and ${summary.unresolved} note issues. All ${summary.unsyncedReviewed} reviewed orders will enter independent Amazon reconciliation after approval.`, summary.unresolved ? "warn" : "good");
    else if (state.phase === "completed") setNotice(`Completed: ${summary.synced} reviewed orders handled.`, "good");
    else if (state.phase === "paused") setNotice(state.pausedReason || "Paused at a safe checkpoint.", "warn");
    else setNotice(`Running ${displayStatus(state.phase)}: ${summary.detailsCaptured} of ${summary.ordersIndexed} order details read.`, "neutral");

    const approvalReady = state?.phase === "review" && Number(summary?.unsyncedReviewed || 0) > 0;
    $("syncGate").hidden = !approvalReady;
    $("approvalToken").textContent = summary?.approvalToken || "";
    $("approvalInput").placeholder = summary?.approvalToken || "";
    $("syncRows").disabled = !approvalReady || $("approvalInput").value.trim() !== summary.approvalToken;
    renderRows();
  }

  async function refresh() {
    const response = await runtimeMessage({ type: "getEbayMonthlyProfit" });
    if (!response?.ok) {
      setNotice(response?.error || "Could not read monthly eBay profit status.", "error");
      return;
    }
    state = response.state || null;
    render();
  }

  $("startRun").addEventListener("click", async () => {
    const monthKey = $("monthKey").value;
    setNotice("Starting one inactive signed-in eBay worker tab...");
    const response = await runtimeMessage({ type: "startEbayMonthlyProfit", options: { monthKey } });
    if (!response?.ok) setNotice(response?.error || "Could not start monthly eBay profit.", "error");
    await refresh();
  });
  $("resumeRun").addEventListener("click", async () => {
    const response = await runtimeMessage({ type: "resumeEbayMonthlyProfit" });
    if (!response?.ok) setNotice(response?.error || "Could not resume monthly eBay profit.", "error");
    await refresh();
  });
  $("pauseRun").addEventListener("click", async () => {
    const response = await runtimeMessage({ type: "stopEbayMonthlyProfit" });
    if (!response?.ok) setNotice(response?.error || "Could not pause monthly eBay profit.", "error");
    await refresh();
  });
  $("resetRun").addEventListener("click", async () => {
    const response = await runtimeMessage({ type: "resetEbayMonthlyProfit" });
    if (!response?.ok) setNotice(response?.error || "Could not reset monthly eBay profit.", "error");
    state = null;
    await refresh();
  });
  $("approvalInput").addEventListener("input", render);
  $("syncRows").addEventListener("click", async () => {
    const confirm = $("approvalInput").value.trim();
    $("syncRows").disabled = true;
    setNotice("Sending the approved reviewed month to note-profit history and the independent Amazon-cost queue...");
    const response = await runtimeMessage({ type: "syncEbayMonthlyProfit", confirm }, 180000);
    if (!response?.ok && !response?.queued) setNotice(response?.error || "Dashboard sync failed.", "error");
    else setNotice(response.queued ? `${response.count} rows queued for dashboard delivery.` : `${response.count} rows synced.`, response.queued ? "warn" : "good");
    $("approvalInput").value = "";
    await refresh();
  });
  document.querySelectorAll(".filter").forEach((button) => button.addEventListener("click", () => {
    filter = button.dataset.filter || "all";
    document.querySelectorAll(".filter").forEach((candidate) => candidate.classList.toggle("active", candidate === button));
    renderRows();
  }));
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "local" && changes.ebayMonthlyProfit) refresh();
  });
  window.addEventListener("ebayMonthlyProfitProgress", refresh);
  $("monthKey").value = priorMonthKey();
  refresh();
  setInterval(refresh, 3000);
})();
