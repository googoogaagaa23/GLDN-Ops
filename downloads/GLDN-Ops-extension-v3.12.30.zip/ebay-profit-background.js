(function attachEbayProfitBackground(root, factory) {
  root.GLDN_EBAY_PROFIT_BACKGROUND = factory(root.GLDN_EBAY_PROFIT_CORE, root.GLDN_FOUNDATION);
})(globalThis, (CORE, FOUNDATION) => {
  const STORAGE_KEY = "ebayMonthlyProfit";
  const ORDERS_URL = "https://www.ebay.com/sh/ord/";

  const storageGet = (keys) => new Promise((resolve) => chrome.storage.local.get(keys, resolve));
  const storageSet = (values) => new Promise((resolve, reject) => {
    chrome.storage.local.set(values, () => {
      const error = chrome.runtime.lastError?.message;
      if (error) reject(new Error(error));
      else resolve();
    });
  });
  const storageRemove = (keys) => new Promise((resolve) => chrome.storage.local.remove(keys, resolve));

  function tabGet(tabId) {
    return new Promise((resolve) => chrome.tabs.get(tabId, (tab) => resolve(chrome.runtime.lastError ? null : tab)));
  }

  function tabCreate(options) {
    return new Promise((resolve, reject) => chrome.tabs.create(options, (tab) => {
      const error = chrome.runtime.lastError?.message;
      if (error) reject(new Error(error));
      else resolve(tab);
    }));
  }

  function tabUpdate(tabId, options) {
    return new Promise((resolve, reject) => chrome.tabs.update(tabId, options, (tab) => {
      const error = chrome.runtime.lastError?.message;
      if (error) reject(new Error(error));
      else resolve(tab);
    }));
  }

  function tabRemove(tabId) {
    return new Promise((resolve) => {
      if (!Number.isInteger(Number(tabId))) return resolve(false);
      chrome.tabs.remove(Number(tabId), () => resolve(!chrome.runtime.lastError));
    });
  }

  function sendToTab(tabId, message) {
    return new Promise((resolve) => {
      if (!Number.isInteger(Number(tabId))) return resolve({ ok: false });
      chrome.tabs.sendMessage(Number(tabId), message, (response) => {
        resolve(chrome.runtime.lastError ? { ok: false } : (response || { ok: true }));
      });
    });
  }

  async function readRun() {
    const stored = await storageGet([STORAGE_KEY]);
    return stored[STORAGE_KEY] || null;
  }

  async function writeRun(run) {
    const next = { ...run, updatedAt: new Date().toISOString() };
    await storageSet({ [STORAGE_KEY]: next });
    return next;
  }

  function publicResult(run) {
    return { ok: true, state: run, summary: CORE.summary(run) };
  }

  function runtimeVersion() {
    return String(chrome.runtime.getManifest().version || "");
  }

  function isWorker(run, sender) {
    return Boolean(run && Number(run.workerTabId) === Number(sender?.tab?.id));
  }

  async function ownerTab(sender = {}) {
    if (Number.isInteger(sender?.tab?.id)) return sender.tab;
    return new Promise((resolve) => chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => resolve(tabs?.[0] || null)));
  }

  async function createWorker(run, sender = {}) {
    const owner = await ownerTab(sender);
    const windowId = Number.isInteger(run.ownerWindowId)
      ? run.ownerWindowId
      : (Number.isInteger(owner?.windowId) ? owner.windowId : undefined);
    const worker = await tabCreate({
      url: "about:blank",
      active: false,
      ...(Number.isInteger(windowId) ? { windowId } : {})
    });
    return writeRun({
      ...run,
      ownerTabId: run.ownerTabId ?? owner?.id ?? null,
      ownerWindowId: run.ownerWindowId ?? owner?.windowId ?? null,
      workerTabId: worker.id
    });
  }

  async function navigateWorker(run, url) {
    const worker = await tabGet(Number(run.workerTabId));
    if (!worker) throw new Error("The eBay profit worker tab was closed. Use Resume to continue from the saved checkpoint.");
    await tabUpdate(worker.id, { url, active: false, autoDiscardable: false });
    return run;
  }

  async function finishReview(run) {
    const workerTabId = Number(run.workerTabId);
    const preservedWorker = Number.isInteger(workerTabId)
      && workerTabId > 0
      && Boolean(await tabGet(workerTabId));
    const review = await writeRun({
      ...run,
      active: false,
      stopRequested: false,
      phase: "review",
      workerTabId: preservedWorker ? workerTabId : null,
      workerPreserved: preservedWorker,
      workerFailure: null,
      reviewReadyAt: run.reviewReadyAt || new Date().toISOString()
    });
    void sendToTab(review.ownerTabId, { type: "ebayMonthlyProfitProgress", state: review, summary: CORE.summary(review) });
    return publicResult(review);
  }

  async function pauseAtCheckpoint(run, reason = "Paused at a safe checkpoint.", options = {}) {
    const workerTabId = Number(run.workerTabId);
    const closeWorker = options.closeWorker !== false;
    const preservedWorker = !closeWorker
      && Number.isInteger(workerTabId)
      && workerTabId > 0
      && Boolean(await tabGet(workerTabId));
    const paused = await writeRun({
      ...run,
      active: false,
      stopRequested: false,
      phase: "paused",
      resumePhase: run.phase === "paused" ? (run.resumePhase || "index-orders") : run.phase,
      workerTabId: preservedWorker ? workerTabId : null,
      pausedReason: reason,
      workerPreserved: preservedWorker,
      workerFailure: options.failure || null
    });
    if (closeWorker && Number.isInteger(workerTabId) && workerTabId > 0) void tabRemove(workerTabId);
    void sendToTab(paused.ownerTabId, { type: "ebayMonthlyProfitProgress", state: paused, summary: CORE.summary(paused) });
    return publicResult(paused);
  }

  async function pauseMissingWorker(run, reason = "The eBay profit worker tab closed before completion. Resume continues from the saved checkpoint.") {
    if (!run?.active) return run;
    const workerTabId = Number(run.workerTabId);
    if (Number.isInteger(workerTabId) && workerTabId > 0 && await tabGet(workerTabId)) return run;
    const result = await pauseAtCheckpoint(run, reason);
    return result.state;
  }

  async function handleWorkerTabClosed(tabId) {
    const run = await readRun();
    if (!run?.active || Number(run.workerTabId) !== Number(tabId)) {
      return { ok: true, changed: false, state: run };
    }
    const result = await pauseAtCheckpoint(
      run,
      "The eBay profit worker tab closed before completion. Resume continues from the saved checkpoint."
    );
    return { ...result, changed: true };
  }

  async function start(options = {}, sender = {}) {
    await pauseIncompatibleVersion("start-check");
    const existing = await pauseMissingWorker(await readRun());
    if (existing?.active) return { ok: false, error: `An eBay profit run is already active (${existing.phase}).` };
    const stored = await storageGet(["computerLabel", "ebayAccountLabel"]);
    const identity = FOUNDATION.identityForComputer(stored.computerLabel);
    if (!identity.computerLabel || identity.poshmarkOnly || !identity.ebayAccountLabel) {
      return { ok: false, error: "Choose an eBay computer in Setup before starting eBay profit." };
    }
    const owner = await ownerTab(sender);
    let run = CORE.createRun({
      ...options,
      computerLabel: identity.computerLabel,
      accountLabel: identity.ebayAccountLabel,
      extensionVersion: runtimeVersion(),
      ownerTabId: sender?.tab?.id ?? owner?.id ?? null,
      ownerWindowId: sender?.tab?.windowId ?? owner?.windowId ?? null
    });
    if (existing?.workerTabId) await tabRemove(existing.workerTabId);
    run = await createWorker(run, sender);
    await navigateWorker(run, ORDERS_URL);
    return publicResult(run);
  }

  async function stop() {
    const run = await readRun();
    if (!run) return { ok: true, state: null, summary: null };
    if (!run.active) return publicResult(run);
    return pauseAtCheckpoint(run, "Paused by the operator. Resume continues from this exact order checkpoint.");
  }

  async function reset() {
    const run = await readRun();
    if (run?.workerTabId) await tabRemove(run.workerTabId);
    await storageRemove([STORAGE_KEY]);
    return { ok: true, state: null, summary: null };
  }

  async function resume(sender = {}) {
    await pauseIncompatibleVersion("resume-check");
    let run = await readRun();
    if (!run) return { ok: false, error: "No eBay monthly profit checkpoint exists." };
    if (run.phase === "review" || run.phase === "completed") return publicResult(run);
    if (run.active && await tabGet(Number(run.workerTabId))) return publicResult(run);
    const phase = run.phase === "paused" ? String(run.resumePhase || "index-orders") : String(run.phase || "index-orders");
    const preservedWorker = await tabGet(Number(run.workerTabId));
    run = await writeRun({
      ...run,
      active: true,
      stopRequested: false,
      phase,
      pausedReason: "",
      workerPreserved: false,
      workerFailure: null,
      extensionVersion: runtimeVersion()
    });
    if (!preservedWorker) run = await createWorker(run, sender);
    if (phase === "capture-details") {
      const order = (run.orders || [])[Number(run.detailIndex || 0)];
      if (!order?.pageUrl) return finishReview(run);
      await navigateWorker(run, order.pageUrl);
    } else {
      await navigateWorker(run, ORDERS_URL);
    }
    return publicResult(run);
  }

  async function handleOrdersPage(payload, sender) {
    let run = await readRun();
    if (!isWorker(run, sender) || run.phase !== "index-orders") return { ok: false, ignored: true };
    if (run.stopRequested) return pauseAtCheckpoint(run);
    const records = Array.isArray(payload?.records) ? payload.records : [];
    if (payload?.scope?.allOrders !== true || payload?.scope?.ready !== true) {
      const reason = payload?.scope?.reason || "Monthly eBay profit stopped because the worker could not verify a ready All orders page.";
      return pauseAtCheckpoint(run, `${reason} The failed eBay tab was left open for inspection.`, {
        closeWorker: false,
        failure: { phase: run.phase, message: reason, url: String(sender?.tab?.url || "") }
      });
    }
    if (!records.length && payload?.readyEvidence !== "explicit-empty") {
      const reason = "Monthly eBay profit stopped because eBay displayed order links but none could be indexed. No zero-order report was created.";
      return pauseAtCheckpoint(run, `${reason} The failed eBay tab was left open for inspection.`, {
        closeWorker: false,
        failure: { phase: run.phase, message: reason, url: String(sender?.tab?.url || "") }
      });
    }
    run = await writeRun({
      ...CORE.mergeOrdersPage(run, records, { hasNext: payload.hasNext }),
      workerFailureCount: 0,
      workerFailure: null
    });
    if (run.phase === "index-orders") {
      if (payload.nextUrl) {
        await navigateWorker(run, payload.nextUrl);
        return { ...publicResult(run), instruction: "worker-navigating" };
      }
      return { ...publicResult(run), instruction: "next-page" };
    }
    const first = (run.orders || [])[0];
    if (!first?.pageUrl) return finishReview(run);
    await navigateWorker(run, first.pageUrl);
    return { ...publicResult(run), instruction: "worker-navigating" };
  }

  async function handlePeriodPrepared(payload, sender) {
    const run = await readRun();
    if (!isWorker(run, sender) || run.phase !== "index-orders" || run.scope !== "all") {
      return { ok: false, ignored: true };
    }
    const prepared = payload?.prepared === true;
    const attempts = prepared
      ? Number(run.periodConfigureAttempts || 0) + 1
      : Number(run.periodConfigureAttempts || 0);
    if (attempts > 3) {
      return pauseAtCheckpoint(run, "The eBay Custom history range did not stay applied after three attempts. The signed-in worker tab was left open for inspection.", {
        closeWorker: false,
        failure: { phase: run.phase, message: "Custom history range did not stay applied.", url: String(sender?.tab?.url || "") }
      });
    }
    const next = await writeRun({
      ...run,
      periodPrepared: prepared,
      periodConfigureAttempts: attempts,
      periodConfiguredAt: prepared ? new Date().toISOString() : null
    });
    return publicResult(next);
  }

  async function handleWorkerError(payload, sender) {
    const run = await readRun();
    if (!isWorker(run, sender)) return { ok: false, ignored: true };
    const message = String(payload?.message || "The eBay monthly profit worker stopped before producing verified page evidence.").trim();
    const failure = {
      phase: String(payload?.phase || run.phase || "unknown"),
      message,
      url: String(payload?.url || sender?.tab?.url || ""),
      at: new Date().toISOString()
    };
    return pauseAtCheckpoint(run, `${message} The failed eBay tab was left open for inspection; Resume will reuse it.`, {
      closeWorker: false,
      failure
    });
  }

  async function handleOrderDetail(detail, sender) {
    let run = await readRun();
    if (!isWorker(run, sender) || run.phase !== "capture-details") return { ok: false, ignored: true };
    if (run.stopRequested) return pauseAtCheckpoint(run);
    run = await writeRun({
      ...CORE.mergeDetail(run, detail || {}),
      workerFailureCount: 0,
      workerFailure: null
    });
    if (run.phase === "review") return finishReview(run);
    const next = (run.orders || [])[Number(run.detailIndex || 0)];
    if (!next?.pageUrl) return finishReview(run);
    await navigateWorker(run, next.pageUrl);
    return { ...publicResult(run), instruction: "worker-navigating" };
  }

  async function getStatus() {
    const run = await pauseMissingWorker(await readRun());
    return run ? publicResult(run) : { ok: true, state: null, summary: null };
  }

  async function confirmNoteAmounts(orderNumber, input = {}) {
    const run = await readRun();
    if (!run || run.phase !== "review") throw new Error("Monthly eBay profit has not reached note review.");
    const next = await writeRun(CORE.confirmNoteAmounts(run, orderNumber, input));
    void sendToTab(next.ownerTabId, { type: "ebayMonthlyProfitProgress", state: next, summary: CORE.summary(next) });
    return publicResult(next);
  }

  async function pendingForSync() {
    const run = await readRun();
    if (!run || run.phase !== "review") throw new Error("Monthly eBay profit has not reached review.");
    return {
      run,
      results: CORE.unsyncedReviewResults(run),
      records: CORE.unsyncedExactResults(run).map((result) => result.record),
      reviewRecords: CORE.reviewRecords(run)
    };
  }

  async function markSynced(orderNumbers, options = {}) {
    const run = await readRun();
    if (!run) throw new Error("The eBay profit checkpoint is missing.");
    const workerTabId = Number(run.workerTabId);
    const syncedOrderNumbers = [...new Set([...(run.syncedOrderNumbers || []), ...(orderNumbers || []).map(String)])];
    const remaining = CORE.unsyncedReviewResults({ ...run, syncedOrderNumbers });
    const next = await writeRun({
      ...run,
      syncedOrderNumbers,
      ...(remaining.length ? {} : {
        active: false,
        phase: "completed",
        workerTabId: null,
        workerPreserved: false,
        completedAt: new Date().toISOString(),
        syncDelivery: options.queued === true ? "queued" : "confirmed"
      })
    });
    if (!remaining.length && Number.isInteger(workerTabId) && workerTabId > 0) void tabRemove(workerTabId);
    return next;
  }

  async function pauseIncompatibleVersion(reason = "extension-update") {
    const run = await readRun();
    if (!run || String(run.extensionVersion || "") === runtimeVersion()) return { ok: true, changed: false, state: run };
    if (run.workerTabId) await tabRemove(run.workerTabId);
    if (run.phase === "review" || run.phase === "completed") {
      const migrated = await writeRun({ ...run, active: false, workerTabId: null, extensionVersion: runtimeVersion(), migrationReason: reason });
      return { ok: true, changed: true, state: migrated };
    }
    const paused = await writeRun({
      ...run,
      active: false,
      phase: "paused",
      resumePhase: run.phase === "paused" ? (run.resumePhase || "index-orders") : run.phase,
      workerTabId: null,
      extensionVersion: runtimeVersion(),
      pausedReason: `Paused safely because GLDN Ops changed from v${run.extensionVersion || "unknown"} to v${runtimeVersion()}.`,
      migrationReason: reason
    });
    return { ok: true, changed: true, state: paused };
  }

  return Object.freeze({
    STORAGE_KEY,
    start,
    stop,
    reset,
    resume,
    getStatus,
    confirmNoteAmounts,
    handleOrdersPage,
    handlePeriodPrepared,
    handleOrderDetail,
    handleWorkerError,
    handleWorkerTabClosed,
    pendingForSync,
    markSynced,
    pauseIncompatibleVersion
  });
});
