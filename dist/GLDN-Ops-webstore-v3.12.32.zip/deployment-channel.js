globalThis.GLDN_DEPLOYMENT_CHANNEL = 'webstore';
