@echo off
setlocal
echo GLDN Ops installer starting...
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-latest.ps1"
set "exitCode=%ERRORLEVEL%"
if not "%exitCode%"=="0" (
  echo.
  echo Install validation failed. No Chrome extension was changed.
  pause
  exit /b %exitCode%
)
echo.
echo Open chrome://extensions in each intended signed-in Chrome profile once.
echo Then click Load unpacked and select the stable extension folder printed above.
echo.
pause
