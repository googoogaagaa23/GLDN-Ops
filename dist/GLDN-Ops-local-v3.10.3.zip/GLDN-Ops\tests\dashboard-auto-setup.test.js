const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const background = fs.readFileSync(path.join(root, 'extension', 'background.js'), 'utf8');
const popupHtml = fs.readFileSync(path.join(root, 'extension', 'popup.html'), 'utf8');
const popupJs = fs.readFileSync(path.join(root, 'extension', 'popup.js'), 'utf8');
const publicConfig = fs.readFileSync(path.join(root, 'extension', 'config.example.js'), 'utf8');
const installer = fs.readFileSync(path.join(root, 'bootstrap-install.ps1'), 'utf8');

test('private dashboard settings self-seed before every dashboard operation', () => {
  assert.match(background, /async function getDashboardConfig\(\)\s*\{[\s\S]*?await seedDashboardSetupFromLocalConfig\(\);[\s\S]*?storageGet/);
  assert.match(background, /return \{ ok: true, changed, source: 'private-package' \}/);
  assert.match(background, /Automatic dashboard setup is unavailable\. Reinstall or update from the private GLDN Ops package\./);
});

test('automatic dashboard setup runs across every extension lifecycle', () => {
  assert.match(background, /onInstalled\.addListener\(\(details\) => \{\s*seedAutomaticDashboardSetup\(`/);
  assert.match(background, /onStartup\.addListener\(\(\) => \{\s*seedAutomaticDashboardSetup\('chrome-startup'\)/);
  assert.match(background, /seedAutomaticDashboardSetup\('worker-start'\);/);
  assert.match(popupJs, /async function initializePopup\(\) \{\s*await ensureAutomaticDashboardSetup\(\);/);
});

test('popup has automatic status and repair without manual code controls', () => {
  assert.match(popupHtml, /id="dashboardAutoSetup"/);
  assert.match(popupHtml, /id="repairDashboardSetup"[^>]*>Repair Automatic Connection<\/button>/);
  assert.doesNotMatch(popupHtml, /dashboardSetupKey|Save Setup Code|Clear Setup Code/);
  assert.doesNotMatch(popupJs, /saveDashboardSetup|clearDashboardSetup|dashboardSetupKeyInput/);
  assert.match(popupJs, /type: 'seedDashboardSetupFromLocalConfig'/);
});

test('installer uses a verified private package without prompting and public config stays empty', () => {
  assert.match(installer, /Automatic dashboard connection included in this private package\./);
  assert.doesNotMatch(installer, /Read-Host\s+"Enter the private dashboard setup code/);
  assert.match(installer, /Applying the verified private stable extension package/);
  assert.match(installer, /gldn-update-agent\.ps1/);
  assert.match(publicConfig, /dashboardKey:\s*""/);
});
