const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const vm = require("node:vm");

const root = path.resolve(__dirname, "..");
const ebay = fs.readFileSync(path.join(root, "extension", "ebay.js"), "utf8");
const background = fs.readFileSync(path.join(root, "extension", "background.js"), "utf8");
const amazon = fs.readFileSync(path.join(root, "extension", "amazon.js"), "utf8");
const popupHtml = fs.readFileSync(path.join(root, "extension", "popup.html"), "utf8");
const popupJs = fs.readFileSync(path.join(root, "extension", "popup.js"), "utf8");
const manifest = JSON.parse(fs.readFileSync(path.join(root, "extension", "manifest.json"), "utf8"));

function loadCountHelpers() {
  const start = ebay.indexOf("  function parseEcomSniperExtractTotals");
  const end = ebay.indexOf("  function currentEcomSniperExtractLabel", start);
  assert.ok(start >= 0 && end > start, "EcomSniper count helpers must be present");
  const context = {};
  vm.runInNewContext(`${ebay.slice(start, end)}\nthis.countHelpers = { parseEcomSniperExtractTotals, verifyEcomSniperExtractCounts, formatVerifiedEcomSniperExtract, summarizeVerifiedEcomSniperRun, formatVerifiedEcomSniperRun };`, context);
  return context.countHelpers;
}

test("EcomSniper Extract Sellers uses a semantic in-page click without a local helper", () => {
  assert.match(ebay, /async function clickEcomSniperButtonSemantically\(element\)/);
  assert.match(ebay, /if \(!isEbaySearchResultsPage\(\)\)/);
  assert.match(ebay, /!element\?\.isConnected \|\| !U\.isVisible\(element\)/);
  assert.match(ebay, /\\bextract\\s\+sellers\\b/i);
  assert.match(ebay, /new MutationObserver\(\(\) =>/);
  assert.match(ebay, /observer\.observe\(element, \{[\s\S]*?childList: true,[\s\S]*?attributes: true,[\s\S]*?attributeFilter: \["disabled", "class", "aria-busy"\][\s\S]*?\}\);[\s\S]*?element\.click\(\);/);
  assert.match(ebay, /const verification = verifyEcomSniperExtractCounts\(beforeLabel, afterLabel, \{ sawProcessing \}\)/);
  assert.match(ebay, /confirmation: "verified-count-change"/);
  assert.doesNotMatch(ebay, /clickViaLocalHelper/);
  assert.doesNotMatch(ebay, /type:\s*["']localClick["']/);
});

test("automatic click failure stops safely instead of advancing the workflow", () => {
  assert.match(ebay, /phase: "auto-click-failed"/);
  assert.match(ebay, /Automatic EcomSniper Extract Sellers click was not confirmed/);
  assert.match(ebay, /if \(pending\.phase === "auto-click-failed"\)/);
  assert.match(ebay, /completeEcomSniperExtractStep\(clickResult\.verification, clickResult\.afterLabel/);
  assert.doesNotMatch(ebay, /trustedClickReady/);
});

test("C-04 live probe exercises the production timeout recovery without marketplace actions", () => {
  assert.match(ebay, /async function runEcomSniperRecoveryProbeFromUrl\(\)/);
  assert.match(ebay, /url\.searchParams\.get\("gldnC04Probe"\) !== ECOMSNIPER_RECOVERY_PROBE/);
  assert.match(ebay, /url\.searchParams\.get\("gldnC04Confirm"\) !== "1"/);
  assert.match(ebay, /startedAt: now - ECOMSNIPER_CLICK_TIMEOUT_MS - 1000/);
  assert.match(ebay, /await resumePendingEcomSniperBulkExtract\(\);/);
  assert.match(ebay, /marketplaceActions: 0/);
  assert.match(ebay, /lastEcomSniperRecoveryProbe/);
  assert.match(ebay, /saved\?\.mode === "forced-timeout"/);
  assert.match(ebay, /saved\?\.marketplaceActions === 0/);
  assert.match(ebay, /C-04 live recovery passed: forced timeout stopped safely, storage verified; no marketplace action ran/);
});

test("EcomSniper count parser does not turn missing values into zero", () => {
  const { parseEcomSniperExtractTotals } = loadCountHelpers();
  assert.deepEqual({ ...parseEcomSniperExtractTotals("Extract Sellers") }, { total: null, fresh: null });
});

test("EcomSniper extraction reports one reconciled before/after result", () => {
  const { verifyEcomSniperExtractCounts, formatVerifiedEcomSniperExtract } = loadCountHelpers();
  const result = verifyEcomSniperExtractCounts(
    "Extract Sellers (0 new, 892 total)",
    "Extract Sellers (+54 new, 946 total)"
  );
  assert.deepEqual(
    { ok: result.ok, beforeTotal: result.beforeTotal, afterTotal: result.afterTotal, newSellers: result.newSellers, reportedNew: result.reportedNew, source: result.source },
    { ok: true, beforeTotal: 892, afterTotal: 946, newSellers: 54, reportedNew: 54, source: "ecomsniper-extract-sellers-button" }
  );
  assert.equal(formatVerifiedEcomSniperExtract(result), "EcomSniper verified: 892 -> 946 total (+54 new).");
});

test("EcomSniper extraction fails closed when its new and total counts disagree", () => {
  const { verifyEcomSniperExtractCounts } = loadCountHelpers();
  const result = verifyEcomSniperExtractCounts(
    "Extract Sellers (0 new, 892 total)",
    "Extract Sellers (+55 new, 946 total)"
  );
  assert.equal(result.ok, false);
  assert.match(result.error, /count mismatch/i);
});

test("EcomSniper zero-new result requires an observed processing cycle", () => {
  const { verifyEcomSniperExtractCounts } = loadCountHelpers();
  const before = "Extract Sellers (0 new, 946 total)";
  const after = "Extract Sellers (0 new, 946 total)";
  assert.equal(verifyEcomSniperExtractCounts(before, after).ok, false);
  const completed = verifyEcomSniperExtractCounts(before, after, { sawProcessing: true });
  assert.equal(completed.ok, true);
  assert.equal(completed.newSellers, 0);
});

test("verified EcomSniper result is saved separately from scanner inventory", () => {
  assert.match(ebay, /lastEcomSniperExtractResult: verifiedResult/);
  assert.match(ebay, /source: "ecomsniper-extract-sellers-button"/);
  assert.doesNotMatch(ebay, /Competitor Scanner count/);
  assert.match(popupHtml, /id="lastEcomSniperStep"/);
  assert.match(popupHtml, /id="lastEcomSniperRun"/);
  assert.match(popupJs, /function renderEcomSniperVerifiedCounts\(step, run\)/);
});

test("complete EcomSniper run uses its original total and final total", () => {
  const { summarizeVerifiedEcomSniperRun, formatVerifiedEcomSniperRun } = loadCountHelpers();
  const result = summarizeVerifiedEcomSniperRun({ runStartTotal: 892, runAfterTotal: 1607, runVerifiedSteps: 14 });
  assert.deepEqual(
    { ok: result.ok, startTotal: result.startTotal, finalTotal: result.finalTotal, newSellers: result.newSellers, verifiedSteps: result.verifiedSteps, source: result.source },
    { ok: true, startTotal: 892, finalTotal: 1607, newSellers: 715, verifiedSteps: 14, source: "ecomsniper-extract-sellers-button-run" }
  );
  assert.equal(formatVerifiedEcomSniperRun(result), "EcomSniper run verified: 892 -> 1,607 total (+715 new across 14 steps).");
  assert.match(ebay, /lastEcomSniperWorkflowResult: completedWorkflowResult/);
});

test("health and popup report helper-free automatic click mode", () => {
  assert.match(background, /mode: 'semantic-dom'/);
  assert.match(background, /required: false/);
  assert.match(background, /localHelperRequired: false/);
  assert.match(popupHtml, />Automatic<\/span>/);
  assert.match(popupJs, /semantic-dom-extract-sellers/);
  assert.match(popupJs, /Automatic semantic Extract Sellers click/);
});

test("automatic click mode does not add debugger or extension-management permissions", () => {
  assert.ok(!manifest.permissions.includes("debugger"));
  assert.ok(!manifest.permissions.includes("management"));
});

test("stop and reset cancel GLDN seller extraction before another page opens", () => {
  assert.match(ebay, /storageGet\(\["pendingEcomSniperBulkExtract", "gldnStopRequested", "bulkLinksAmazonQueue"\]\)/);
  assert.match(ebay, /if \(result\.gldnStopRequested\)/);
  assert.match(ebay, /bulkLinksAmazonQueue:\s*\{[\s\S]*?active: false,[\s\S]*?stoppedAt: Date\.now\(\)/);
  assert.match(ebay, /"pendingAmazonBulkWorkflowStart"[\s\S]*?"pendingAmazonSnipingWorkflowStart"[\s\S]*?"bulkLinksAmazonQueue"/);
  assert.doesNotMatch(popupHtml, /id="startBulkListingWorkflow"/);
  assert.doesNotMatch(popupJs, /pendingAmazonBulkWorkflowStart:\s*\{\s*active:\s*true/);
  assert.match(amazon, /if \(result\.pendingAmazonBulkWorkflowStart\?\.active\) \{[\s\S]*?storageRemove\(\["pendingAmazonBulkWorkflowStart"\]\)/);
  assert.doesNotMatch(amazon, /pendingAmazonBulkWorkflowStart\?\.active[\s\S]{0,160}startBulkLinksFromAmazon\(\)/);
});

test("handoff monitor reports only GLDN-observable state", () => {
  assert.match(popupHtml, /id="ecomSniperMonitorCard"/);
  assert.match(popupHtml, /id="refreshEcomSniperMonitor"/);
  assert.match(popupHtml, /id="stopEcomSniperAssist"/);
  assert.match(popupJs, /function renderEcomSniperMonitor\(result = \{\}\)/);
  assert.match(popupJs, /Internal EcomSniper progress is unknown/);
  assert.match(popupJs, /Closing the tab does not prove completion/);
  assert.match(background, /observableScope: 'tab-lifecycle-only'/);
  assert.match(background, /chrome\.tabs\?\.onRemoved\?\.addListener/);
  assert.doesNotMatch(popupJs, /Bulk Poster (?:running|complete|completed)/i);
});

test("60-day product history is written only after a confirmed seller extraction", () => {
  assert.doesNotMatch(amazon, /rememberBulkProducts\(/);
  assert.match(ebay, /async function rememberConfirmedBulkProduct\(pending\)/);
  assert.match(ebay, /if \(!pending\?\.bulkQueue \|\| !pending\.query\) return/);
  assert.match(ebay, /await rememberConfirmedBulkProduct\(bulk\);[\s\S]*?phase: "after-extract"/);
  assert.match(amazon, /async function recoverLegacyBulkHistoryReservations\(\)/);
  assert.match(amazon, /queue\.titles\.slice\(lastAttemptedIndex \+ 1\)/);
  assert.match(amazon, /historyMode: "confirmed-only"/);
});
